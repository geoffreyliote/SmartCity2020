<template>
    <div>
        <v-card-title
    >
      Active Game(s)
      <v-spacer></v-spacer>
      <div class="my-2">
       <v-btn  color="#B10276" dark>Create a new game</v-btn>
      </div>
      <v-spacer></v-spacer>
      <v-text-field
        v-model="search"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="games"
    >
 <template v-slot:item.action="{ item }">
     <v-btn  color="#B10276" @click="clickedElement(item.id)" dark>Manage</v-btn>
    </template>
    </v-data-table>
    </div>
</template>

<script>
const axios = require('axios');
const Api = require('@/Services/Api');


export default {
  name: 'ActiveGames',
  props: {
    headers: Array,
  },
  data() {
    return {
      games: [],
    };
  },
  created() {
    // login not implemented
    this.GetGames(2);
  },
  methods: {
    // Get all games in progress created by the actual organizer
    GetGames(idOrganizer) {
      axios.get(`${Api.ApiBaseUrl}Game/organizer/${idOrganizer}`)
        .then((response) => { this.games = response.data; });
    },

    // Go to the game page of the selected game
    clickedElement(item) {
      this.$router.push(`/GameDetails/${item}`);
    },
  },
};
</script>

<style scoped>

</style>
