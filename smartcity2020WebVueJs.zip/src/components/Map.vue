<template>
    <div id="map">

    </div>
</template>

<script>
/* eslint-disable */

const mapboxgl = require('mapbox-gl/dist/mapbox-gl.js');


export default {
  name: 'MapVue',
  props: {
    data: Array,
    center: Array,
  },
  data() {
    return {
      datasource: this.data, // position of the steps
    };
  },
  created() {

  },
  // Display a map and add the steps of the current game
  mounted() {
    mapboxgl.accessToken = 'pk.eyJ1IjoiZ3Jldm9yZCIsImEiOiJjanJyZ3NqcmswMWhjNDNucDJxNDQydGlhIn0.lKFKKtTiUzkpDZyYCy0P0g';
    const map = new mapboxgl.Map({
      container: 'map', // container of the map
      style: 'mapbox://styles/mapbox/streets-v9', // style of the map
      center: [5.0167, 47.3167], // starting position [lng, lat]
      zoom: 12, // starting zoom
    });
    map.on('load', () => {
      console.log('validate', 'true');
      map.addSource('steps', {
      'type': 'geojson',
      'data': {
      'type': 'FeatureCollection',
      'features': this.datasource
      }
      });
      map.addLayer({
        id: 'steps',
        type: 'symbol',
        source: 'steps',
        layout: {
          // get the icon name from the source's "icon" property
          // concatenate the name to get an icon from the style's sprite sheet
          'icon-image': ['concat', ['get', 'icon'], '-15'],
          // get the title name from the source's "title" property
          'text-field': ['get', 'title'],
          'text-font': ['Open Sans Semibold', 'Arial Unicode MS Bold'],
          'text-offset': [0, 0.6],
          'text-anchor': 'top',
        },
      });
    });
  },
};
/* eslint-enable */
</script>

<style>
 #map{
   height: 100%;
 }
</style>
