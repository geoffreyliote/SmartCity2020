<template>
    <div id="mapContainer">
    </div>
</template>

<script >
/* eslint-disable */
import {StepCreation} from '../views/StepCreation.vue';
const mapboxgl = require('mapbox-gl/dist/mapbox-gl.js');


export default {
  name: 'MapStep',
  props: ['coord'],
  data() {
    return {
 markerPosition: null, // position of the marker
 marker: undefined,
    }
  },
  created() {

  },
  // display a map and allow admin to place a marker for adding a step
  mounted() {
    mapboxgl.accessToken = 'pk.eyJ1IjoiZ3Jldm9yZCIsImEiOiJjanJyZ3NqcmswMWhjNDNucDJxNDQydGlhIn0.lKFKKtTiUzkpDZyYCy0P0g';
    const map = new mapboxgl.Map({
      container: 'mapContainer', // container of the map
      style: 'mapbox://styles/mapbox/streets-v9', // style of the map
      center: [5.0167, 47.3167], // starting position [lng, lat]
      zoom: 12, // starting zoom

    });
    map.on('load', () => {
      console.log('validate', 'true');
    });
    map.on('click', (onMap, evt) => {
      // if there is no marker, it create one
        if (this.markerPosition == undefined) {
           this.marker = new mapboxgl.Marker().setLngLat(onMap.lngLat).addTo(map)
           this.markerPosition = onMap.lngLat
           this.$emit('getcoord', onMap.lngLat)
        }
        // if there actually a marker, it move the old
       else{
        this.marker.setLngLat(onMap.lngLat)
         this.markerPosition = onMap.lngLat
         this.$emit('getcoord', onMap.lngLat)
       }
    })
  },
};
/* eslint-enable */
</script>

<style>
 #mapContainer{
   height: 150%;
   width: 680px;
 }
</style>
