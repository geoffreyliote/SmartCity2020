<template>
    <div>
        <v-card
    class="mx-auto"
    max-width="600"
  >
    <v-card-title
      class="blue-grey white--text"
    >
      <span class="title">Game Events</span>
      <v-spacer></v-spacer>
      <v-btn
        :outlined="interval == null"
        :color="interval == null ? 'white' : 'primary'"
        dark
        depressed
        @click="interval == null ? start() : stop()"
      >
        Realtime Logging
      </v-btn>
    </v-card-title>
    <v-card-text class="py-0">
      <v-timeline dense>
        <v-slide-x-reverse-transition
          group
          hide-on-leave
        >
          <v-timeline-item
            v-for="item in items"
            :key="item.id"
            :color="item.color"
            small
            fill-dot
          >
            <v-alert
              :value="true"
              :color="item.color"
              :icon="item.icon"
              class="white--text"
            >
              team {{item.id}} started the game
            </v-alert>
          </v-timeline-item>
        </v-slide-x-reverse-transition>
      </v-timeline>
    </v-card-text>
  </v-card>
    </div>
</template>

<script>

const COLORS = [
  'info',
  'warning',
  'error',
  'success',
];
const ICONS = {
  info: 'mdi-information',
  warning: 'mdi-alert',
  error: 'mdi-alert-circle',
  success: 'mdi-check-circle',
};

export default {
  data: () => ({
    interval: null, // define the interval where the message appears
    items: [
      {
        id: 1,
        color: 'info',
        icon: ICONS.info,
      },
    ],
    nonce: 2,
  }),

  beforeDestroy() {
    this.stop();
  },

  methods: {
    addEvent() {
      let { color } = this.genAlert();
      const icon = this.genAlert();
      const previousColor = this.items[0].color;

      while (previousColor === color) {
        color = this.genColor();
      }

      this.items.unshift({
        id: this.nonce + 1,
        color,
        icon,
      });
      if (this.nonce > 6) {
        this.items.pop();
      }
    },
    genAlert() {
      const color = this.genColor();

      return {
        color,
        icon: this.genIcon(color),
      };
    },
    // generate random color for the message
    genColor() {
      return COLORS[Math.floor(Math.random() * 3)];
    },
    genIcon(color) {
      return ICONS[color];
    },
    // start the logs
    start() {
      this.interval = setInterval(this.addEvent, 3000);
    },
    // stop the logs
    stop() {
      clearInterval(this.interval);
      this.interval = null;
    },
  },
};
</script>

<style scoped>

</style>
