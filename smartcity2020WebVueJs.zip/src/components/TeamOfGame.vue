<template>
<div>
  <v-bottom-sheet v-model="sheet" persistent>
      <template v-slot:activator="{ on }">
           <v-expansion-panels>
    <v-expansion-panel
      v-for="item in teams"
      :key="item.Id"
    >
      <v-expansion-panel-header>
     <v-switch value input-value="true"></v-switch>
    {{item.Name}}
          <div class="my-2 ml-5">
        <v-btn
        dark
        v-on="on"
        @click="SetStepSource(item.Id)"
        >See details</v-btn>
      </div>
      <div>
       Score : {{item.Plays[0].Score}}
      </div>
      </v-expansion-panel-header>
      <v-expansion-panel-content
       v-for="player in item.Teamplayers"
      :key="player.Player.Id">
        {{player.Player.FirstName}} {{player.Player.LastName}}
       </v-expansion-panel-content>
    </v-expansion-panel>
  </v-expansion-panels>
      </template>
      <v-sheet class="text-center" height="200px">
        <v-btn
          class="mt-6"
          flat
          color="error"
          @click="sheet = !sheet, GetStepsOfTeams()"
        >close</v-btn>
        <spacer></spacer>
        <v-stepper :value="CurrentStep" v-if="CurrentStep != null" class="mt-3">
    <v-stepper-header>
        <div v-for="step in SelectedTeamProgress" :key="step.stepOrder">
      <v-stepper-step :step="step.stepOrder"
      v-if="step.completed === true" complete>{{step.name}}</v-stepper-step>
      <v-stepper-step :step="step.stepOrder" v-else >{{step.name}}</v-stepper-step>
      <v-divider></v-divider>
      </div>
    </v-stepper-header>
  </v-stepper>
  <div v-else>
    <br>
    <h1>Completed</h1></div>
      </v-sheet>
    </v-bottom-sheet>
</div>
</template>

<script>
const axios = require('axios');
const Api = require('@/Services/Api');

export default {
  name: 'TeamOfGame',
  props: {
    GameId: String,
  },
  data() {
    return {
      checkbox1: true,
      teams: {},
      sheet: false,
      progressOfTeams: [],
      SelectedTeamProgress: {},
      CurrentStep: undefined,
    };
  },
  created() {
    this.GetTeams();
    this.GetStepsOfTeams();
  },
  methods: {
    // get the teams of the actual game
    GetTeams() {
      axios.get(`${Api.ApiBaseUrl}Game/${this.GameId}/Teams`)
        .then((response) => { this.teams = response.data; });
    },
    // get the actual progress of the teams
    GetStepsOfTeams() {
      axios.get(`${Api.ApiBaseUrl}Game/${this.GameId}/Progress`)
        .then((response) => { this.progressOfTeams = response.data; });
    },
    // Display the progress bar of each team
    SetStepSource(idTeam) {
      const ListOfSteps = [];
      const arraycompleted = [];
      this.progressOfTeams.forEach((Team) => {
        if (Team.teamId === idTeam) {
          ListOfSteps.push(Team);
          if (Team.completed === false) {
            arraycompleted.push(Team);
          }
        }
      });
      if (arraycompleted[0] !== undefined) {
        this.CurrentStep = arraycompleted[0].stepOrder;
      }
      this.SelectedTeamProgress = ListOfSteps;
    },
  },
};
</script>

<style scoped>

</style>
