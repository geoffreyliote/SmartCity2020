//
// Examples of how Api call should be made
//

export const ApiBaseUrl = 'http://localhost:63737/api/';

const axios = require('axios');

// Get old games
export function GetGameHistory() {
  axios.get(`${ApiBaseUrl}Game`)
    .then(response => response.data);
}
// set the routes
export function GetRoutes() {
  axios.get(`${ApiBaseUrl}Route`)
    .then((response) => { this.routes = response.data; });
}
