<template>
<div>
  <ActiveGames :headers='headers'></ActiveGames>
  <v-card-title
    >
      Games ended
      <v-spacer></v-spacer>
      <v-text-field
        v-model="search"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="gameHistory"
    >
    </v-data-table>
</div>
</template>

<script>

import ActiveGames from '../components/ActiveGames.vue';

const axios = require('axios');
const Api = require('@/Services/Api');

export default {
  name: 'Game',

  data: () => ({
    isLoading: false,
    dialog: false,
    headers: [
      {
        text: 'Game',
        align: 'left',
        sortable: false,
        value: 'name',
      },
      { text: 'Transport', value: 'transport' },
      { text: 'Organizer', value: 'organizer' },
      { text: 'Route', value: 'route' },
      { text: 'Actions', value: 'action', sortable: false },
    ],
    gameHistory: [], // history of games
    onGoingGames: [], // game In progress
    editedIndex: -1,
    editedItem: {
      name: '',
      Transport: '',
      Organizer: '',
      Route: '',
    },
    defaultItem: {
      name: '',
      Transport: '',
      Organizer: 0,
      Route: 0,
    },
    datas: [],
  }),
  created() {
    this.GetRoutes();
    this.GetGameHistory();
    this.GetTransports();
  },
  components: {
    ActiveGames,
  },
  methods: {
    // get the history of all the game
    GetGameHistory() {
      axios.get(`${Api.ApiBaseUrl}Game`)
        .then((response) => { this.gameHistory = response.data; });
    },
    // get all routes
    GetRoutes() {
      axios.get(`${Api.ApiBaseUrl}Route`)
        .then((response) => { this.routes = response.data; });
    },
    // get all transports
    GetTransports() {
      axios.get(`${Api.ApiBaseUrl}Transport`)
        .then((response) => { this.transports = response.data; });
    },
    editItem(item) {
      this.editedIndex = this.games.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.dialog = true;
    },

    deleteItem() {
    },

    close() {
      this.dialog = false;
      setTimeout(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      }, 300);
    },

    save() {
      if (this.editedIndex > -1) {
        Object.assign(this.games[this.editedIndex], this.editedItem);
      } else {
        this.games.push(this.editedItem);
      }
      this.close();
    },
  },


};
</script>

<style>

</style>
