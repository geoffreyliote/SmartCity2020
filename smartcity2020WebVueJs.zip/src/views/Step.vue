<template>
<div>
   <v-card>
    <v-card-title
    >
    <v-card-text style="height: 100px; position: relative">
            <v-fab-transition>
              <v-btn
                v-show="!hidden"
                color="pink"
                dark
                left
                fab
                to="/StepCreation"
              >
                <v-icon>mdi-plus</v-icon>
              </v-btn>
            </v-fab-transition>
          </v-card-text>
      Steps
      <v-spacer></v-spacer>
      <v-text-field
        v-model="search"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="steps"
      :search="search"
    >
     <template v-slot:body="{ items }">
        <tbody>
          <tr v-for="item in items" :key="item.name">
            <td>{{ item.name }}</td>
            <td>{{ item.description }}</td>
            <td> <v-icon
        small
        class="mr-2"
        @click="consultMission(item.id)"
      >
        mdi-clipboard-list-outline
      </v-icon>
      </td>
            <td>
              <v-icon
              small
              class="mr-2"
              @click="editStep(item.id)">
              mdi-pencil
              </v-icon>
              <v-icon
              small
              class="mr-2"
              @click="deleteStep()">
              mdi-delete-forever
              </v-icon></td>
          </tr>
        </tbody>
      </template>
    </v-data-table>
  </v-card>
<v-snackbar
      v-model="snackbar"
    >
      {{ text }}
      <v-btn
        color="pink"
        text
        @click="snackbar = false"
      >
        Close
      </v-btn>
    </v-snackbar>
    <v-snackbar
      v-model="snackbar2"
      :bottom="y === 'bottom'"
      :left="x === 'left'"
      :multi-line="mode === 'multi-line'"
      :right="x === 'right'"
      :timeout="timeout"
      :top="y === 'top'"
      :vertical="mode === 'vertical'"
    >
      {{ textSnackBar }}
      <v-btn
        color="pink"
        flat
        @click="snackbar2 = false"
      >
        Close
      </v-btn>
    </v-snackbar>
</div>
</template>

<script>

const axios = require('axios');
const Api = require('@/Services/Api');

export default {
  data() {
    return {
      snackbar: false, // do not display the snackbar per default
      text: '',
      search: '', // search bar
      headers: [ // headers of the Steps Table
        { text: 'Step name', value: 'name' },
        { text: 'description', value: 'description' },
        { text: 'mission' },
        { text: 'action' },
      ],
      steps: [], // all step created
      step: '',
      snackbar2: false,
      y: 'top',
      x: null,
      mode: '',
      timeout: 6000,
      textSnackBar: 'Disabled for the demonstration',
    };
  },
  created() {
    this.loadData();
  },
  methods: {
    // call all step
    loadData() {
      axios.get(`${Api.ApiBaseUrl}Step`)
        .then((response) => {
          this.steps = response.data;
        });
    },
    // delete a step if it is not assigned to a route
    // eslint-disable-next-line no-unused-vars
    deleteStep(stepId) {
      this.snackbar2 = true;
      // console.log(stepId);
      // axios.post(`${Api.ApiBaseUrl}Step/DeleteStep/${stepId}`)
      //   .then((response) => { this.text = response.data; this.snackbar = true; });
      // // eslint-disable-next-line no-restricted-globals
      // location.reload();
    },
    // push to the edit page
    editStep(stepId) {
      this.$router.push(`/StepEdit/${stepId}`);
    },
    consultMission(id) {
      this.$router.push(`/Mission/${id}`);
    },
  },
};
</script>

<style>

</style>
