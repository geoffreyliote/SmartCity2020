<template>

<div class="row fullrow">
      <div class="col">
        <MapVue :data="mapData" :center="center"></MapVue>
      </div>
      <div class="col">
        <TeamOfGame :GameId="gameId" ></TeamOfGame>
      </div>
      <div class="col">
        <feed-game></feed-game>
      </div>
</div>
</template>

<script>

import MapVue from '../components/Map.vue';
import FeedGame from '../components/FeedGameEvent.vue';
import TeamOfGame from '../components/TeamOfGame.vue';

const axios = require('axios');
const Api = require('@/Services/Api');

export default {
  name: 'gameDetails',
  data() {
    return {
      gameId: '', // id of the game
      mydata: {},
      mapData: [],
      center: undefined,
    };
  },
  created() {
    this.gameId = this.$route.params.id;
    this.EditSourceToMap();
    this.ShowSteps();
  },
  components: {
    MapVue,
    FeedGame,
    TeamOfGame,
  },
  methods: {
    EditSourceToMap(stepName, lat, long) {
      // / To do : Set a method to generate a point to display on a map from coordinates
      // To do so simply request the api with the data containing the coordinates
      // for example the steps coordinates
      /* eslint-disable */
      this.mapData.push({
      // feature for Mapbox SF
        'type': 'Feature',
        'geometry': {
        'type': 'Point',
        'coordinates': [long, lat]
        },
        'properties': {
        'title': 'Step: '+stepName,
        'icon': 'circle-stroked'
        }
      });
      /* eslint-enable */
    },
    // get all steps of a game and transform them into a geojson type
    ShowSteps() {
      axios.get(`${Api.ApiBaseUrl}Game/${this.gameId}/Steps`)
        .then((res) => {
          res.data.forEach(item => this.EditSourceToMap(item.name, item.lat, item.lng));
        });
    },
  },
};
</script>

<style scoped>

  .fullrow{
    height: 100%;
  }

</style>
