<template>
  <v-form
    ref="form"
    v-model="valid"
    lazy-validation
  >
    <v-text-field
      v-model="name"
      :counter="100"
      :rules="nameRules"
      label="Name"
      required
    ></v-text-field>
    <v-textarea
      v-model="description"
      :rules="descriptionRules"
      label="Description"
      required
    ></v-textarea>
  <v-text-field
  v-model="lien"
  :rules="lienRules"
    label="Lien de l'image"
    filled
    prepend-icon="mdi-camera"
    required
  ></v-text-field>
  <v-row>
          <v-col cols="10" sm="10" md="1">
          <v-text-field v-bind:value="this.latitude"
            label="Latitude"
            placeholder="Latitude"
            outlined
            readonly
          ></v-text-field>
          </v-col>
          <v-col cols="10" sm="10" md="1">
          <v-text-field v-bind:value="this.longitude"
            label="Longitude"
            placeholder="Longitude"
            outlined
            readonly
          ></v-text-field>
        </v-col>
    <v-btn
      :disabled="!valid"
      color="success"
      class="mr-4"
      @click="validate"
    >
      Validate
    </v-btn>

    <v-btn
      color="error"
      class="mr-4"
      @click="reset"
    >
      Reset Form
    </v-btn>
    </v-row>
          <div class="col" name="test" style="height: 324px;">
        <MapStep v-on:getcoord="getCoord" />
      </div>
  </v-form>
</template>
<script>
import MapStep from '../components/MapStep.vue';

const axios = require('axios');
const Api = require('@/Services/Api');

export default {
  props: {
    center: Array,
  },
  data: () => ({
    valid: true,
    name: '', // name of the step
    nameRules: [
      v => !!v || 'Name is required',
      v => (v && v.length <= 100) || 'Name must be less than 100 characters',
    ],
    description: '', // description of the description
    descriptionRules: [
      v => !!v || 'Description is required',
    ],
    lien: '', // link of the image
    lienRules: [
      v => !!v || 'Link is required',
    ],
    files: [],
    file: [],
    latitude: null, // latitude of the step
    longitude: null, // longitude of the step
    selectedFile: null,
  }),
  created() {
    this.loadData();
  },
  components: {
    MapStep,
  },
  methods: {
  // transform the coordinates array into 2 page variables
    getCoord(lngLat) {
      this.latitude = lngLat.lat;
      this.longitude = lngLat.lng;
    },
    // Validate the creation of a Step and push to the Step Table (only if the position is informed)
    validate() {
      if (this.longitude != null) {
        axios.post(`${Api.ApiBaseUrl}Step/Create`,
          {
            Description: this.description,
            Name: this.name,
            Lat: this.latitude,
            Lng: this.longitude,
            Validation: this.lien,
          }).then(this.$router.push('/step'));
      } else {
        // eslint-disable-next-line no-alert
        alert('Merci de sélectionner une position');
      }
    },
    // Reset all the field
    reset() {
      this.$refs.form.reset();
    },
  },
};

</script>
