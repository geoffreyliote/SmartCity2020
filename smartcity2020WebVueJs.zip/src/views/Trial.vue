
<template>
<div>
  <v-data-table
    :headers="headers"
    :items="trials"
    :single-expand="true"
    :expanded.sync="expanded"
    item-key="Libelle"
    show-expand
    class="elevation-1"
  >
    <template v-slot:top>
      <v-toolbar flat>
        <v-toolbar-title>Trials</v-toolbar-title>
        <v-spacer></v-spacer>
        <v-btn color="primary" dark class="mb-2" @click="CreateTrial(MissionId)">
          New Trial
        </v-btn>
      </v-toolbar>
    </template>
    <template v-slot:expanded-item="{ headers, item }">
      <td :colspan="headers.length">
        <div v-for="answer in item.Answers" :key="answer.Id">
          {{ answer.Libelle }}
        </div>
      </td>
    </template>
    <template v-slot:item.action="{ item }">
      <v-icon
        small
        class="mr-2"
        @click="EditTrial(item)"
      >
        mdi-pencil
      </v-icon>
      <v-icon
        small
        @click="DeleteTrial(item.Id)"
      >
        mdi-delete
      </v-icon>
    </template>
  </v-data-table>
  <v-snackbar
      v-model="snackbar"
    >
      {{ text }}
      <v-btn
        color="pink"
        text
        @click="snackbar = false"
      >
        Close
      </v-btn>
    </v-snackbar>
    <v-dialog v-model="dialog" max-width="750px">
          <v-card>
            <v-card-title>
              <span class="headline">Edit trial</span>
            </v-card-title>
            <v-card-text>
              <v-container>
                  <v-row cols="12" sm="6" md="4">
                    <v-text-field v-model="editedItem.Libelle" label="Label"></v-text-field>
                  </v-row>
                  <v-row cols="12" sm="6" md="4">
                    <v-text-field v-model="editedItem.Score" label="Score"></v-text-field>
                  </v-row>
                  <v-row>
                    <v-select
                      v-model="selectedAnswer"
                      :items="editedItem.Answers"
                      item-text="Libelle"
                      label="Answers"
                      persistent-hint
                    ></v-select>
                  </v-row>
                    <v-row v-if="editedItem.SelectedAnswer != null" cols="12" sm="6" md="4">
                      <v-text-field v-model="selectedAnswer"
                        label="Selected answer">
                      </v-text-field>
                    </v-row>
                    <v-row v-else cols="12" sm="6" md="4">
                      <v-text-field v-model="newAnswerLibelle"
                        label="New answer" :value="editedItem.Libelle">
                      </v-text-field>
                      <v-btn class="mx-2" fab dark color="#B10276">
                        <v-icon @click="AddToAnswers(newAnswer)" dark>mdi-plus</v-icon>
                      </v-btn>
                    </v-row>
                  <v-row>
                    <v-select
                      v-model="editedItem.CorrectAnswer"
                      :items="editedItem.Answers"
                      item-text="Libelle"
                      label="Correct answer"
                      persistent-hint
                      return-object
                    ></v-select>
                  </v-row>
              </v-container>
            </v-card-text>

            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="blue darken-1" text @click="close">Cancel</v-btn>
              <v-btn color="blue darken-1" text @click="save">Save</v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
  </div>
</template>

<script>
// the script element will make all of the treatement of your page
// ///////////
// Imports //

// ///////////
// Requires//
const axios = require('axios');
const api = require('@/Services/Api');
// //////////
// To do : //
export default {
  name: 'Trial', // Name of the page //

  data() {
    return {
      trials: undefined, // all trials
      snackbar: false, // snackbar
      text: '',
      selectedAnswer: undefined,
      dialog: false,
      editedIndex: -1,
      newAnswerLibelle: '',
      defaultItem: {
        Libelle: '',
        Score: 0,
        CorrectAnswer: '',
        answers: [],
      },
      editedItem: {
        Id: 0,
        Libelle: '',
        Score: 0,
        CorrectAnswer: '',
        Answers: [],
      },
      newAnswer: {
        TrialId: undefined,
        Libelle: '',
        Picture: null,
        TeamAnswers: [],
        Trials: [],
      },
      expanded: [],
      headers: [
        {
          text: 'Label', align: 'left', sortable: false, value: 'Libelle',
        },
        { text: 'Score', sortable: false, value: 'Score' },
        { text: 'Actions', value: 'action', sortable: false },
      ],
    };
  },
  // In here you can call différents elements :
  // Created will execute action when the page is called
  created() {
    this.MissionId = this.$route.params.id;
  },
  // Mounted will execute action when the page is rendered
  // /
  mounted() {
    this.GetTrials(this.MissionId);
  },
  // Components will register others vues to be used in this one
  // /
  // Methods will register methods to be used in this page
  // data will register variables for the page
  // Methods and data of this page can be used by using this.myVar
  methods: {
    GetTrials(id) {
      axios.get(`${api.ApiBaseUrl}Mission/${id}/Trials`)
        .then((response) => { this.trials = response.data; });
    },
    CreateTrial(id) {
      this.$router.push(`/Mission/${id}/NewTrial`);
    },
    EditTrial(trial) {
      this.editedIndex = this.trials.indexOf(trial);
      this.editedItem = Object.assign({}, trial);
      this.editedTrialId = trial.Id;
      this.dialog = true;
    },
    DeleteTrial(trialId) {
      axios.post(`${api.ApiBaseUrl}Mission/DeleteTrial/${trialId}`)
        .then((response) => { this.text = response.data; this.snackbar = true; });
    },
    close() {
      this.dialog = false;
      setTimeout(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      }, 300);
    },
    save() {
      if (this.editedIndex > -1) {
        // Object.assign(this.trials[this.editedIndex], this.editedItem);
        axios.post(`${api.ApiBaseUrl}Mission/EditTrials`, this.editedItem)
          .then((response) => { this.text = response.data; });
      } else {
        this.trials.push(this.editedItem);
      }
      this.close();
    },
    AddToAnswers() {
      this.newAnswer.Libelle = this.newAnswerLibelle;
      this.newAnswer.TrialId = this.editedItem.Id;
      this.editedItem.Answers.push(this.newAnswer);
      this.newAnswerLibelle = '';
    },
  },
};
</script>

<style scoped>
/* A scoped style is a css that only affect this page */


</style>
