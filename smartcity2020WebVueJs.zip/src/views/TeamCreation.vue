<template>
  <v-form
    ref="form"
    v-model="valid"
    lazy-validation
  >
    <v-text-field
      v-model="name"
      :counter="100"
      :rules="nameRules"
      label="Team's name"
      required
    ></v-text-field>
    <v-btn
      :disabled="!valid"
      color="success"
      class="mr-4"
      @click="validate"
    >
      Validate
    </v-btn>

    <v-btn
      color="error"
      class="mr-4"
      @click="reset"
    >
      Reset Form
    </v-btn>
  </v-form>
</template>
<script>
//  const axios = require('axios');
//  const Api = require('@/Services/Api');

export default {
  data: () => ({
    valid: true,
    name: '',
    nameRules: [
      v => !!v || 'Name is required',
      v => (v && v.length <= 100) || 'Name must be less than 100 characters',
    ],
    description: '',
    descriptionRules: [
      v => !!v || 'Description is required',
    ],
    files: [],
    file: [],
    selectedFile: null,
  }),

  methods: {
    validate() {
    },
    reset() {
      this.$refs.form.reset();
    },
  },
};
</script>
