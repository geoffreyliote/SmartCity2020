<template>
<div>
   <v-card>
    <v-card-title
    >
    <v-card-text style="height: 100px; position: relative">
            <v-fab-transition>
              <v-btn
                v-show="!hidden"
                color="pink"
                dark
                left
                fab
                to="/RouteCreation"
              >
                <v-icon>mdi-plus</v-icon>
              </v-btn>
            </v-fab-transition>
          </v-card-text>
      Routes
      <v-spacer></v-spacer>
      <v-text-field
        v-model="search"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="routes"
      :search="search"
    >
    </v-data-table>
  </v-card>

</div>
</template>

<script>

const axios = require('axios');
const Api = require('@/Services/Api');

export default {
  data() {
    return {
      search: '',
      headers: [
        { text: 'Route name', value: 'name' },
        { text: 'description', value: 'description' },
        { text: 'distance', value: 'distance' },
      ],
      routes: undefined,
      route: '',
    };
  },
  created() {
    this.loadData();
  },
  methods: {
    // load all route
    loadData() {
      axios.get(`${Api.ApiBaseUrl}Route`)
        .then((response) => {
          this.routes = response.data;
        });
    },
  },
};
</script>

<style>

</style>
