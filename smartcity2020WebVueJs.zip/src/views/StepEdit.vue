<template>
  <v-form
    ref="form"
    v-model="valid"
    lazy-validation
  >
    <v-text-field
      v-model="name"
      :counter="100"
      :rules="nameRules"
      label="Name"
      required
    ></v-text-field>
    <v-textarea
      v-model="description"
      :rules="descriptionRules"
      label="Description"
      required
    ></v-textarea>
  <v-text-field
  v-model="lien"
  :rules="lienRules"
    label="Lien de l'image"
    filled
    prepend-icon="mdi-camera"
    required
  ></v-text-field>
  <v-row>
          <v-col cols="10" sm="10" md="1">
          <v-text-field v-bind:value="this.latitude"
            label="Latitude"
            placeholder="Latitude"
            outlined
            readonly
          ></v-text-field>
          </v-col>
          <v-col cols="10" sm="10" md="1">
          <v-text-field v-bind:value="this.longitude"
            label="Longitude"
            placeholder="Longitude"
            outlined
            readonly
          ></v-text-field>
        </v-col>
    <v-btn
      :disabled="!valid"
      color="success"
      class="mr-4"
      @click="validate"
    >
      Validate
    </v-btn>

    <v-btn
      color="error"
      class="mr-4"
      @click="reset"
    >
      Reset Form
    </v-btn>
    </v-row>
          <div class="col" name="test" style="height: 324px;">
        <MapStep v-on:getcoord="getCoord" />
      </div>
  </v-form>
</template>
<script>
import MapStep from '../components/MapStep.vue';

const axios = require('axios');
const Api = require('@/Services/Api');

export default {
  name: 'StepEdit',
  props: {
    center: Array,
  },
  data: () => ({
    valid: true,
    nameRules: [
      v => !!v || 'Name is required',
      v => (v && v.length <= 100) || 'Name must be less than 100 characters',
    ],
    description: '', // description of the step
    descriptionRules: [
      v => !!v || 'Description is required',
    ],
    lien: '', // link of the image
    lienRules: [
      v => !!v || 'Link is required',
    ],
    files: [],
    file: [],
    latitude: null, // latitude of the step
    longitude: null, // longitude of the step
    selectedFile: null,
    response: null,
  }),
  components: {
    MapStep,
  },
  created() {
    this.loadData();
  },
  methods: {
    // load and fill all field of the Step to Edit
    loadData() {
      axios.get(`${Api.ApiBaseUrl}Step/${this.$route.params.id}`)
        .then((response) => {
          this.response = response.data;
          this.name = response.data.name;
          this.description = response.data.description;
          this.latitude = response.data.lat;
          this.longitude = response.data.lng;
          this.lien = response.data.validation;
        });
    },
    // transform the coordinates array into 2 page variables
    getCoord(lngLat) {
      this.latitude = lngLat.lat;
      this.longitude = lngLat.lng;
    },
    // validate the edit and
    validate() {
      axios.post(`${Api.ApiBaseUrl}Step/Edit/${this.$route.params.id}`,
        {
          Description: this.description,
          Name: this.name,
          Lat: this.latitude,
          Lng: this.longitude,
          Validation: this.lien,
        }).then(this.$router.push('/step'));
    },
    // reset the fields
    reset() {
      this.name = this.response.name;
      this.description = this.response.description;
      this.latitude = this.response.lat;
      this.longitude = this.response.lng;
      this.lien = this.response.validation;
    },
  },
};

</script>
