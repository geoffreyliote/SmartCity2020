

<!--
     All of the content of the page that will be visible
    Will be created here in the template
    Only 1 global element should be present here
 -->

 <template>
<div>
   <v-card>
    <v-card-title
    >
    <v-card-text style="height: 100px; position: relative">
            <v-fab-transition>
              <v-btn
                v-show="!hidden"
                color="pink"
                dark
                left
                fab
                to="/StepCreation"
              >
                <v-icon>mdi-plus</v-icon>
              </v-btn>
            </v-fab-transition>
          </v-card-text>
      Mission
      <v-spacer></v-spacer>
      <v-text-field
        v-model="search"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="missions"
      :search="search"    >
     <template v-slot:body="{ items }">
        <tbody>
          <tr v-for="item in items" :key="item.name">
            <td>{{ item.name }}</td>
            <td>{{ item.description }}</td>
            <td>{{ item.score}}</td>
            <td> <v-icon
        small
        class="mr-2"
        @click="consultTrial(item.id)"
      >
        mdi-clipboard-list-outline
      </v-icon>
      </td>
      </tr>
        </tbody>
      </template>
    </v-data-table>
  </v-card>
<EditMission :hidden="editHidden"></EditMission>
</div>
</template>

<script>
// the script element will make all of the treatement of your page
// ///////////
// Imports //


// ///////////
// Requires//

const Axios = require('axios');
const Api = require('@/Services/Api');

// //////////
// To do : //
export default {
  name: 'Mission', // Name of the page //
  data() {
    return {
      idStep: '',
      selectedMissionId: '',
      editHidden: false,
      missions: [],
      headers: [
        { text: 'Mission', value: 'name' },
        { text: 'Description', value: 'description' },
        { text: 'Points', value: 'score' },
        { text: 'trials' },
      ],

    };
  },
  created() {
    this.idStep = this.$route.params.id;
    this.loadData();
  },
  methods: {
    loadData() {
      Axios.get(`${Api.ApiBaseUrl}mission/step/${this.idStep}`)
        .then((response) => {
          console.log(response.data);
          this.missions = response.data;
        });
    },
    consultTrial(id) {
      this.$router.push(`/Mission/Trial/${id}`);
    },
  },

};
</script>

<style scoped>
/* A scoped style is a css that only affect this page */


</style>
