<template>

<!--
     All of the content of the page that will be visible
    Will be created here in the template
    Only 1 global element should be present here
 -->

<div>

   <v-card>
    <v-card-title
    >
    <v-card-text style="height: 100px; position: relative">
            <v-fab-transition>
              <v-btn
                v-show="!hidden"
                color="pink"
                dark
                left
                fab
                to="/TeamCreation"
              >
                <v-icon>mdi-plus</v-icon>
              </v-btn>
            </v-fab-transition>
          </v-card-text>
      Teams
      <v-spacer></v-spacer>
      <v-text-field
        v-model="search"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="teams"
      :search="search"
    >
     <template v-slot:body="{ items }">
        <tbody>
          <tr v-for="item in items" :key="item.name">
            <td>{{ item.name }}</td>
            <td>{{ item.LeaderName }}</td>
            <td>{{ item.NbP }}</td>
            <td>{{ item.OrgName}}</td>


            <td>
              <v-icon
              small
              class="mr-2"
              @click="EditTeam(item.id)">
              mdi-pencil
              </v-icon>
              <v-icon
              small
              class="mr-2"
              @click="DeleteTeam(item.id)">
              mdi-delete-forever
              </v-icon></td>
          </tr>
        </tbody>
      </template>
    </v-data-table>
  </v-card>


</div>
</template>

<script>

const axios = require('axios');
const Api = require('@/Services/Api');

// the script element will make all of the treatement of your page
// ///////////
// Imports //
// ///////////
// Requires//
// //////////
// To do : //

export default {
  data() {
    return {
      search: '', // searchbar
      headers: [ // headers of the Teams Table
        {
          text: 'Teams',
          value: 'name',
        },
        { text: 'Leader', value: 'LeaderName' },
        { text: 'Number of players', value: 'NbP' },
        { text: 'Organizer', value: 'OrgName' },
        { text: 'Action', value: 'Action' },
      ],
      teams: [], // All teams
      team: '',
    };
  },
  created() {
    this.loadData();
  },
  methods: { // Loead all Team
    loadData() {
      axios.get(`${Api.ApiBaseUrl}Team2`)
        .then((response) => {
          this.patate = response.data;
          this.patate.forEach((team) => {
            this.teams.push({
              name: team.Name,
              LeaderName: `${team.Captain.FirstName} ${team.Captain.LastName}`,
              NbP: team.Teamplayers.length,
              OrgName: `${team.Organizer.FirstName} ${team.Organizer.LastName}`,


            });
          });
        });
    },
    EditTeam() {
    },
    DeleteTeam() {
    },
  },


  name: undefined, // Name of the page //
  // In here you can call différents elements :
  // Created will execute action when the page is called
  // Mounted will execute action when the page is rendered
  // /
  // Components will register others vues to be used in this one
  // Methods will register methods to be used in this page
  // data will register variables for the page
  // Methods and data of this page can be used by using this.myVar
};
</script>

<style>

</style>
