
<template>
<!--
     All of the content of the page that will be visible
    Will be created here in the template
    Only 1 global element should be present here
 -->
    <div>

    </div>
</template>

<script>
// the script element will make all of the treatement of your page
// ///////////
// Imports //

// ///////////
// Requires//

// //////////
// To do : //
export default {
  name: undefined, // Name of the page //
  // In here you can call différents elements :
  // Created will execute action when the page is called
  // Mounted will execute action when the page is rendered
  // /
  // Components will register others vues to be used in this one
  // Methods will register methods to be used in this page
  // data will register variables for the page

  // Methods and data of this page can be used by using this.myVar

};
</script>

<style scoped>
/* A scoped style is a css that only affect this page */


</style>
