<template>
  <v-card
    dark
  >
    <template v-slot:progress>
      <v-progress-linear
        absolute
        color="green lighten-3"
        height="4"
        indeterminate
      ></v-progress-linear>
    </template>
      <v-row>
        <v-col
          class="text-right"
          cols="12"
        >
        </v-col>
        <v-row
          class="pa-4"
          align="center"
          justify="center"
        >
        </v-row>
      </v-row>
    <v-form>
      <v-container>
        <v-row>
            <v-text-field
              v-model="newTrial.Libelle"
              filled
              color="blue-grey lighten-2"
              label="Label"
            ></v-text-field>
        </v-row>
        <v-row
            cols="12"
            md="6"
          >
            <v-text-field
              v-model="newTrial.Score"
              filled
              color="blue-grey lighten-2"
              label="Score"
            ></v-text-field>
        </v-row>
        <v-row
            cols="12"
            md="6"
          >
            <v-text-field
              v-model="newAnswer"
              filled
              color="blue-grey lighten-2"
              label="Answer"
            ></v-text-field>
            <v-btn class="mx-2" fab dark color="#B10276">
              <v-icon @click="AddToAnswers(newAnswer)" dark>mdi-plus</v-icon>
            </v-btn>
        </v-row>
          <v-col cols="12">
              <v-select
                v-model="newTrial.CorrectAnswer"
                :items="answers"
                item-text="state"
                label="Select"
                persistent-hint
                return-object
                single-line
              ></v-select>
          </v-col>
      </v-container>
      <v-btn @click="AddTrial(newTrial)" block color="#B10276" dark>Create</v-btn>
    </v-form>
  </v-card>
</template>

<script>

const axios = require('axios');
const api = require('@/Services/Api');

export default {
  name: 'TrialCreation',
  data() {
    return {
      answers: [], // answers of the trial
      newAnswer: '', // new answer
      correctAnswer: '', // correct Answer
      result: '',
      newTrial: { // Properties of the new trial
        Libelle: '',
        MissionId: this.$route.params.id,
        Score: undefined,
        Answers: [],
        CorrectAnswer: this.correctAnswer,
      },
    };
  },
  methods: {
    // add a new answer and clear the newAnswer field
    AddToAnswers(answer) {
      this.answers.push(answer);
      this.newTrial.Answers.push(answer);
      this.newAnswer = '';
    },
    // add a new Trial
    AddTrial(trial) {
      axios.post(`${api.ApiBaseUrl}Mission/NewTrial`, trial)
        .then((response) => { this.result = response.data; });
      this.$router.push(`/Mission/${this.$route.params.id}`);
    },
    consultMission(id) {
      this.$router.push(`/Mission/${id}`);
    },
  },
};
</script>

<style scoped>

</style>
