<template>
  <v-app id="inspire">
    <v-navigation-drawer
      v-model="drawer"
      app
      clipped
      dark
      temporary
      >
      <v-list dense>
        <v-list-item to="/Game" link>
          <v-list-item-action>
            <v-icon>mdi-gamepad-up</v-icon>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title>Games</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item to="/Route" link>
          <v-list-item-action>
            <v-icon>mdi-map-marker-path</v-icon>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title>Routes</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item to="/Step" link>
          <v-list-item-action>
            <v-icon>mdi-map-marker</v-icon>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title>Steps</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-item to="/Team" link>
          <v-list-item-action>
            <v-icon>mdi-account-group</v-icon>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title>Teams</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <v-app-bar
      app
      clipped-left
      color="#B10276"
    >
      <v-app-bar-nav-icon @click.stop="drawer = !drawer" />
      <v-toolbar-title>SmartCity2020</v-toolbar-title>
    </v-app-bar>
    <v-content>
     <router-view/>
    </v-content>
    <v-footer
    app
    >
      <span>SmartCity2020 - Admin/Organizer panel</span>
    </v-footer>
  </v-app>
</template>

<script>


export default {
  name: 'App',
  data: () => ({
    drawer: null,
  }),
  created() {
    this.$vuetify.theme.dark = true;
  },
};
</script>
