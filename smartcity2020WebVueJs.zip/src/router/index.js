import Vue from 'vue';
import VueRouter from 'vue-router';
import Game from '../views/Game.vue';
import Route from '../views/Route.vue';
import Login from '../views/Login.vue';
import GameDetails from '../views/GameDetails.vue';
import RouteCreation from '../views/RouteCreation.vue';
import StepCreation from '../views/StepCreation.vue';
import StepEdit from '../views/StepEdit.vue';

import TeamCreation from '../views/TeamCreation.vue';

import Trial from '../views/Trial.vue';
import TrialCreation from '../views/TrialCreation.vue';
import Mission from '../views/Mission.vue';


Vue.use(VueRouter);

const routes = [
  {
    path: '',
    name: 'Login',
    component: Login,
  },

  {
    path: '/Game',
    name: 'Game',
    component: Game,
  },
  {
    path: '/Team',
    name: 'Team',
    component: () => import('../views/Team.vue'),
  },
  {
    path: '/Route',
    name: 'route',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: Route,
  },
  {
    path: '/Step',
    name: 'step',
    component: () => import('../views/Step.vue'),
  },
  {
    path: '/GameDetails/:id',
    name: 'gameDetails',
    component: GameDetails,
  },
  {
    path: '/RouteCreation',
    name: 'routeCreation',
    component: RouteCreation,
  },
  {
    path: '/TeamCreation',
    name: 'TeamCreation',
    component: TeamCreation,
  },
  {
    path: '/StepCreation',
    name: 'stepCreation',
    component: StepCreation,
  },
  {
    path: '/StepEdit/:id',
    name: 'stepEdit',
    component: StepEdit,
  },
  // Here add a path to your page
  {
    path: '/Mission/:id',
    name: 'Mission',
    component: Mission,
  },
  {
    path: '/Mission/Trial/:id',
    name: 'Trial',
    component: Trial,
  },
  {
    path: '/Mission/:id/NewTrial',
    name: 'Create trial',
    component: TrialCreation,
  },
];

const router = new VueRouter({
  routes,
});
export default router;
