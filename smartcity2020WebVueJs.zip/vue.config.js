module.exports = {
  transpileDependencies: [
    'vuetify',
  ],
};
