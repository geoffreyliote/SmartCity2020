﻿// <copyright file="IStatRepository.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Repository.Contract
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using SmartCity2020.Entities;

    /// <summary>
    /// Inteface corresponding to the repository to get stats of the current game.
    /// </summary>
    public interface IStatRepository
    {
        int GetStepsDone(int id);

        int GetTotalSteps(int id);

        int GetPoints(int id);

        int GetAnswers(int id);

        int GetTotalQuestions(int id);

        List<Play> GetTeamsScores(int id);
    }
}
