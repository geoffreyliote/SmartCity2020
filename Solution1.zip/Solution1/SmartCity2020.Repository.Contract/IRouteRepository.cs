﻿using SmartCity2020.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace SmartCity2020.Repository.Contract
{
    public interface IRouteRepository
    {
        /// <summary>
        /// Get all the existing routes
        /// </summary>
        /// <returns></returns>
        IEnumerable<Route> GetRoutes();
        /// <summary>
        /// Get all the route created by a specific organizer
        /// </summary>
        /// <param name="organizerId">id of the organizer</param>
        /// <returns></returns>
        IEnumerable<Route> GetRoutesByOrganizer(int organizerId);
        /// <summary>
        /// Get the route of a game
        /// May be unused since you can get them from the game itself but in the case of emergency, it exist
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Route GetRouteForGame(int id);

    }
}

