﻿using SmartCity2020.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace SmartCity2020.Repository.Contract
{
    public interface IGameRepository
    {
        IEnumerable<Game> GetGames();
        IEnumerable<Game> GetActiveGame(int id);

        IEnumerable<Team> GetTeamplayers(int id);
        object GetGameProgression(int id);
        List<Step> GetStepsOfGame(int id);
    }
}
