﻿using SmartCity2020.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace SmartCity2020.Repository.Contract
{
    public interface ITransportRepository
    {
       IEnumerable<Transport> GetTransports();

        List<Trial> PourBenj(int id);
    }
}
