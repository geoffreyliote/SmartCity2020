﻿// <copyright file="IQuizzRepository.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Repository.Contract
{
    using SmartCity2020.Entities;
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// Interface correspodning to the repository
    /// </summary>
    public interface IQuizzRepository
    {
        List<Trial> GetTrials(int id);
    }
}
