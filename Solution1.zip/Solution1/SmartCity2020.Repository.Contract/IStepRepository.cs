﻿using Microsoft.AspNetCore.Http;
using SmartCity2020.Entities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace SmartCity2020.Repository.Contract
{
    public interface IStepRepository
    {
        /// <summary>
        /// Get all the existing steps
        /// </summary>
        /// <returns></returns>
        IEnumerable<Step> GetSteps();
        /// <summary>
        /// Get the step associate to the id
        /// </summary>
        /// <returns></returns>
        Step GetStep(int id);
        Task UploadToS3(FileStream fileStream);
        Step GetCurrentStep(int id);
        void QuizzValidation(int id);

        string DeleteStep(int id);        
        void PostStep(Step step);
        void EditStep(Step step);
        Task<string> ValidateStepAsync(int idTeam, int idStep,string uploadedImageName);
    }
}
