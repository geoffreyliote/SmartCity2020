﻿//-----------------------------------------------------------------------
// <copyright file="IPlayerRepository.cs" company="Diiage">
//     DIIAGE
// </copyright>
// <author>Team 1</author>
//-----------------------------------------------------------------------

namespace SmartCity2020.Repository.Contract
{
    using SmartCity2020.Entities;

    /// <summary>
    /// This is the Repository corresponding to the players.
    /// We will have information that we need to use in the profile page of the user's app.
    /// </summary>
    public interface IPlayerRepository
    {
        /// <summary>
        /// Recover all information of the player into the database
        /// </summary>
        /// <param name="id">Id of the connected player</param>
        /// <returns>Info/Stats of the connected player</returns>
        Playerinfo GetInfo(int id);

        int Login(string username, string password);
    }
}
