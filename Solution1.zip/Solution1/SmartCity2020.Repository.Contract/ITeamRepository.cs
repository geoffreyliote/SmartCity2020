﻿
namespace SmartCity2020.Repository.Contract
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using SmartCity2020.Entities;

    public interface ITeamRepository
    {
        Team GetTeam(int id);

        List<Player> GetPlayers(int id);

        Player GetCaptain(int id);

        void CheckAnswer(int answerId, int teamId, int trialId);

        List<Team> GetTeams();

    }
}
