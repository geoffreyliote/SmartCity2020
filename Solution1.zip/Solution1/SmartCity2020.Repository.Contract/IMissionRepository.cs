﻿
namespace SmartCity2020.Repository.Contract
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using SmartCity2020.Entities;

    public interface IMissionRepository
    {
        List<Trial> GetTrials(int id);

        void AddTrial(Trial newTrial, string correctAnswer);

        string DeleteTrial(int id);

        void EditTrials(Trial trial);

        IEnumerable<Mission> GetStepMission(int idStep);
    }
}
