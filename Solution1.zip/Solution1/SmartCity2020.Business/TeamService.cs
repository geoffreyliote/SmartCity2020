﻿// <copyright file="TeamService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Business
{
    using System.Collections.Generic;
    using SmartCity2020.Business.Contract;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;

    /// <summary>
    /// Service which communicate with team repository.
    /// </summary>
    public class TeamService : ITeamService
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TeamService"/> class.
        /// </summary>
        /// <param name="teamRepository">Team repository.</param>
        public TeamService(ITeamRepository teamRepository)
        {
            this.TeamRepository = teamRepository;
        }

        /// <summary>
        /// Gets or sets the team repository.
        /// </summary>
        public ITeamRepository TeamRepository { get; set; }

        /// <summary>
        /// Call the method of the repository to get the current team of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A <see cref="Team"/>.</returns>
        public Team GetTeam(int id)
        {
            return this.TeamRepository.GetTeam(id);
        }

        /// <summary>
        /// Call the method of the repository to get players of the current team.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A list of <see cref="Player"/>.</returns>
        public List<Player> GetPlayers(int id)
        {
            return this.TeamRepository.GetPlayers(id);
        }
        
        /// <summary>
        /// Call the method of the repository to get the captain of the current team.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A <see cref="Player"/>.</returns>
        public Player GetCaptain(int id)
        {
            return this.TeamRepository.GetCaptain(id);
        }

        /// <summary>
        /// Call the method of the repository to check an answer entered by the team.
        /// </summary>
        /// <param name="answerId">Id of the answer.</param>
        /// <param name="teamId">Id of the team.</param>
        /// <param name="trialId">Id of the trial.</param>
        public void CheckAnswer(int answerId, int teamId, int trialId)
        {
            this.TeamRepository.CheckAnswer(answerId, teamId, trialId);
        }

        /// <summary>
        /// Call the method of the repository to get the list of team.
        /// </summary>        
        public List<Team> GetTeams()
        {
            return this.TeamRepository.GetTeams();
        }

    }
}
