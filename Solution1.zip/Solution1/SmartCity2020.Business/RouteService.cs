﻿using SmartCity2020.Business.Contract;
using SmartCity2020.Entities;
using SmartCity2020.Repository.Contract;
using System;
using System.Collections.Generic;
using System.Text;

namespace SmartCity2020.Business
{
    public class RouteService : IRouteService
    {
        public IRouteRepository _routeRepository { get; set; }
        public RouteService(IRouteRepository routeRepository)
        {
            _routeRepository = routeRepository;
        }

        public Route GetRouteForGame(int id)
        {
            return _routeRepository.GetRouteForGame(id);
        }

        public IEnumerable<Route> GetRoutes()
        {
            return _routeRepository.GetRoutes();
        }

        public IEnumerable<Route> GetRoutesByOrganizer(int organizerId)
        {
            return _routeRepository.GetRoutesByOrganizer(organizerId);
        }
    }
}
