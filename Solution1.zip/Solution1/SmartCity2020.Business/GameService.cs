﻿// <copyright file="GameService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Business
{
    using System.Collections.Generic;
    using SmartCity2020.Business.Contract;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;

    /// <summary>
    /// Service which communicate with game repository.
    /// </summary>
    public class GameService : IGameService
    {


        /// <summary>
        /// Initializes a new instance of the <see cref="GameService"/> class.
        /// </summary>
        /// <param name="gameRepository">Game repository.</param>
        public GameService(IGameRepository gameRepository)
        {
            this.GameRepository = gameRepository;
        }

        public IGameRepository GameRepository { get; set; }
        
        public IEnumerable<Game> GetGames()
        {
           return this.GameRepository.GetGames();
        }
        /// <summary>
        /// Get the actives games attribuated to the organizer that made the request
        /// </summary>
        /// <param name="id">Identifier of the organizer that made the request</param>
        /// <returns></returns>
        public IEnumerable<Game> GetActiveGame(int id)
        {
            return GameRepository.GetActiveGame(id);
        }

        public IEnumerable<Team> GetTeamplayers(int id)
        {
            return GameRepository.GetTeamplayers(id);
        }

        public object GetGameProgression(int id)
        {
            return GameRepository.GetGameProgression(id);
        }
        public List<Step> GetStepsOfGame(int id)
        {
            return GameRepository.GetStepsOfGame(id);
        }
    }
}
