﻿//-----------------------------------------------------------------------
// <copyright file="PlayerService.cs" company="Diiage">
//     DIIAGE
// </copyright>
// <author>Team 1</author>
//-----------------------------------------------------------------------

namespace SmartCity2020.Business
{
    using SmartCity2020.Business.Contract;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;

    /// <summary>
    /// This is the Service corresponding to the players.
    /// We will have information that we need to use in the profile page of the user's app.
    /// </summary>
    public class PlayerService : IPlayerService
    {
        /// <summary>
        /// Initializes a new instance of the PlayerService class.
        /// </summary>
        /// <param name="playerRepository">Repository of the PlayerService.</param>
        public PlayerService(IPlayerRepository playerRepository)
        {
            this.PlayerRepository = playerRepository;
        }

        /// <summary>
        /// Gets or sets the Repository of the Service
        /// </summary>
        public IPlayerRepository PlayerRepository { get; set; }

        /// <summary>
        /// Recover all information of the player into the database
        /// </summary>
        /// <param name="id">Id of the connected player</param>
        /// <returns>Info/Stats of the connected player</returns>
        public Playerinfo GetInfo(int id)
        {
            return this.PlayerRepository.GetInfo(id);
        }
        public int Login(string username, string password)
        {
            return this.PlayerRepository.Login(username, password);
        }
    }
}
