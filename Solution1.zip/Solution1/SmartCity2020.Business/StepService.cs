﻿// <copyright file="StepService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Business
{
    using SmartCity2020.Business.Contract;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;
    using System.Threading.Tasks;

    /// <summary>
    /// Service which communicate with step repository.
    /// </summary>
    public class StepService : IStepService
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StepService"/> class.
        /// </summary>
        /// <param name="stepRepository">Step repository.</param>
        public StepService(IStepRepository stepRepository)
        {
            this.StepRepository = stepRepository;
        }

        public IStepRepository StepRepository { get; set; }

        /// <summary>
        /// Call the method of the repository to validate a step.
        /// </summary>
        /// <returns>A boolean which say if the step is validated or not.</returns>
        public async Task<string> ValidateStepAsync(int idTeam, int idStep, string uploadedImageName)
        {

            var result = await StepRepository.ValidateStepAsync(idTeam, idStep, uploadedImageName);
            return result;
        }

        /// <summary>
        /// Call the method of the repository to get the current step of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A <see cref="Step"/>.</returns>
        public Step GetCurrentStep(int id)
        {
            return this.StepRepository.GetCurrentStep(id);
        }

        /// <summary>
        /// Call the method of the repository to validate a quiz.
        /// </summary>
        /// <param name="id">Id of the team.</param>
        public void QuizzValidation(int id)
        {
            this.StepRepository.QuizzValidation(id);
        }
        public IEnumerable<Step> GetSteps()
        {
            return StepRepository.GetSteps();
        }
        public Step GetStep(int id)
        {
            return StepRepository.GetStep(id);
        }
        public string DeleteStep(int id)
        {
            return StepRepository.DeleteStep(id);
        }
        public void PostStep(Step step)
        {
           StepRepository.PostStep(step);
           // WebClient wc = new WebClient();
           // byte[] bytes = wc.DownloadData(step.Validation);
           // MemoryStream ms = new MemoryStream(bytes);
           // FileStream fileStream = new FileStream("../file.jpg", FileMode.Create);
           // ms.WriteTo(fileStream);
           // PostPicture(fileStream);

        }
        public void EditStep(Step step)
        {
            StepRepository.EditStep(step);
        }
        public void PostPicture(FileStream fileStream)
        {
            StepRepository.UploadToS3(fileStream);
        }
    }
}
