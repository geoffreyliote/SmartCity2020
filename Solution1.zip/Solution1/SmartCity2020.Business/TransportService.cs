﻿using SmartCity2020.Business.Contract;
using SmartCity2020.Entities;
using SmartCity2020.Repository.Contract;
using System;
using System.Collections.Generic;
using System.Text;

namespace SmartCity2020.Business
{

    public class TransportService : ITransportService
    {
        public ITransportRepository _TransportRepository { get; set; }

        public TransportService(ITransportRepository transportRepository)
        {
            _TransportRepository = transportRepository;
        }

        public IEnumerable<Transport> GetTransports() => _TransportRepository.GetTransports();

        public List<Trial> PourBenj(int id)
        {
            return _TransportRepository.PourBenj(id);
        }
    }
}
