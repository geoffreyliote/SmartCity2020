﻿// <copyright file="StatService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Business
{
    using System.Collections.Generic;
    using SmartCity2020.Business.Contract;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;

    /// <summary>
    /// Service class corresponding to the stats of a team.
    /// </summary>
    public class StatService : IStatService
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StatService"/> class.
        /// </summary>
        /// <param name="statRepository">Stat repository.</param>
        public StatService(IStatRepository statRepository)
        {
            this.StatRepository = statRepository;
            this.Stats = new TeamInfo();
        }

        /// <summary>
        /// Gets or sets the stat repository.
        /// </summary>
        public IStatRepository StatRepository { get; set; }

        /// <summary>
        /// Gets or sets the information of the team.
        /// </summary>
        public TeamInfo Stats { get; set; }

        /// <summary>
        /// Get stats of the team.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>Stats of the team.</returns>
        public TeamInfo GetStats(int id)
        {
            this.Stats.StepsDone = this.StatRepository.GetStepsDone(id);
            this.Stats.AllSteps = this.StatRepository.GetTotalSteps(id);
            this.Stats.CurrentPoints = this.StatRepository.GetPoints(id);
            this.Stats.AnsweredQuestions = this.StatRepository.GetAnswers(id);
            this.Stats.TotalQuestions = this.StatRepository.GetTotalQuestions(id);

            return this.Stats;
        }

        /// <summary>
        /// Gets scores of all teams participating to the game.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A list of <see cref="Play"/>.</returns>
        public List<Play> GetTeamsScores(int id)
        {
            return this.StatRepository.GetTeamsScores(1);
        }
    }
}
