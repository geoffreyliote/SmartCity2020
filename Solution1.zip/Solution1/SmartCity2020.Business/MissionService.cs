﻿
namespace SmartCity2020.Business
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using SmartCity2020.Business.Contract;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;

    public class MissionService : IMissionService
    {
        public MissionService(IMissionRepository missionRepository)
        {
            this.MissionRepository = missionRepository;
        }

        public IMissionRepository MissionRepository { get; set; }

        public void AddTrial(Trial newTrial, string correctAnswer) => this.MissionRepository.AddTrial(newTrial, correctAnswer);

        public List<Trial> GetTrials(int id) => this.MissionRepository.GetTrials(id);

        public string DeleteTrial(int id) => this.MissionRepository.DeleteTrial(id);

        public void EditTrials(Trial trial) => this.MissionRepository.EditTrials(trial);

        public IEnumerable<Mission> GetStepMission(int idstep) => MissionRepository.GetStepMission(idstep);
    }
}
