﻿// <copyright file="QuizzService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Business
{
    using System.Collections.Generic;
    using SmartCity2020.Business.Contract;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;

    /// <summary>
    /// Service which communicate with quiz repository.
    /// </summary>
    public class QuizzService : IQuizzService
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="QuizzService"/> class.
        /// </summary>
        /// <param name="quizzRepository">Quiz repository.</param>
        public QuizzService(IQuizzRepository quizzRepository)
        {
            this.QuizzRepository = quizzRepository;
        }

        /// <summary>
        /// Gets or sets the quiz repository.
        /// </summary>
        public IQuizzRepository QuizzRepository { get; set; }

        /// <summary>
        /// Gets a trials corresponding to a step.
        /// </summary>
        /// <param name="id">Id of the step.</param>
        /// <returns>A list of <see cref="Trial"/>.</returns>
        public List<Trial> GetTrials(int id)
        {
            return this.QuizzRepository.GetTrials(id);
        }
    }
}
