using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using SmartCity2020.Business;
using SmartCity2020.Business.Contract;
using SmartCity2020.Entities;
using SmartCity2020.Repository;
using SmartCity2020.Repository.Contract;


namespace SmartCity2020.WebAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        readonly string MyAllowSpecificOrigins = "AllowAllHeaders";
        public IConfiguration Configuration { get; }
        public int ConnectedPlayerId { get; set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddDbContext<SmartCity2020Context>();

            services.AddCors(options =>
            {
                options.AddPolicy(MyAllowSpecificOrigins,
                builder =>
                {
                    builder.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod().Build();
                });
            });

            #region AddScoped Repository
            services.AddScoped<IGameRepository, GameRepository>();
       
            services.AddScoped<IStepRepository, StepRepository>();
            services.AddScoped<IPlayerRepository, PlayerRepository>();
            services.AddScoped<ITeamRepository, TeamRepository>();
            services.AddScoped<IRouteRepository, RouteRepository>();
            services.AddScoped<ITransportRepository, TransportRepository>();
            services.AddScoped<IStatRepository, StatRepository>();
            services.AddScoped<IQuizzRepository, QuizzRepository>();
            services.AddScoped<IMissionRepository, MissionRepository>();
            #endregion
            #region AddScoped Services
            services.AddScoped<ITransportService, TransportService>();
            services.AddScoped<IGameService, GameService>();
            services.AddScoped<IStepService, StepService>();
            services.AddScoped<IPlayerService, PlayerService>();
            services.AddScoped<ITeamService, TeamService>();

            services.AddScoped<IRouteService, RouteService>();

            services.AddScoped<IStatService, StatService>();
            services.AddScoped<IQuizzService, QuizzService>();
            services.AddScoped<IMissionService, MissionService>();
            #endregion
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseCors(MyAllowSpecificOrigins);
            

            app.UseRouting();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
