﻿
namespace SmartCity2020.WebAPI.ViewModels
{
    using SmartCity2020.Entities;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    public class EditedTrialViewModel
    {
        public int Id { get; set; }

        public string Libelle { get; set; }

        public int MissionId { get; set; }

        public int Score { get; set; }

        public IEnumerable<Answer> Answers { get; set; }

        public Answer CorrectAnswer { get; set; }
    }
}
