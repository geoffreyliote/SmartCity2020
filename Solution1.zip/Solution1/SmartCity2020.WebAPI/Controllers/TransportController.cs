﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SmartCity2020.Business.Contract;

namespace SmartCity2020.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransportController : ControllerBase
    {
        public ITransportService _TransportService { get; set; }

        public TransportController(ITransportService transportService)
        {
            _TransportService = transportService;
        }

        public IActionResult Get()
        {
            try
            {
               return Ok(_TransportService.GetTransports());
            }
            catch (Exception e)
            {
               return StatusCode(500, e);
            }
        }
        [HttpGet]
        [Route("/api/Benj/{id}")]
        public IActionResult Benj(int id)
        {
            try
            {
                string json = JsonConvert.SerializeObject(_TransportService.PourBenj(id), Formatting.Indented, new JsonSerializerSettings
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
                return Ok(json);
            }
            catch (Exception)
            {

                return StatusCode(500, "ptdr sa marche pô");
            }
        }
    }
}