﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SmartCity2020.Business.Contract;
using SmartCity2020.Entities;
using SmartCity2020.WebAPI.ViewModels;
using Xamarin.Forms.Internals;

namespace SmartCity2020.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MissionController : ControllerBase
    {
        public MissionController(IMissionService missionService)
        {
            this.MissionService = missionService;
        }

        public IMissionService MissionService { get; set; }

        [HttpGet]
        [Route("/api/Mission/{id}/Trials")]
        public IActionResult GetTrials(int id)
        {
            try
            {
                string json = JsonConvert.SerializeObject(this.MissionService.GetTrials(id), Formatting.Indented, new JsonSerializerSettings
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
                return this.Ok(json);
            }
            catch (Exception e)
            {
                return this.StatusCode(500, e);
            }
        }

        [HttpPost]
        [Route("/api/Mission/NewTrial")]
        public IActionResult AddTrial([FromBody] NewTrial newTrial)
        {
            try
            {
                var trial = new Trial
                {
                    Libelle = newTrial.Libelle,
                    MissionId = Int32.Parse(newTrial.MissionId),
                    Score = Int32.Parse(newTrial.Score),
                };
                newTrial.Answers.ForEach(a => trial.Answers.Add(new Answer { Libelle = a }));
                var correctAnswer = newTrial.CorrectAnswer;
                this.MissionService.AddTrial(trial, correctAnswer);
                return this.Ok("done");
            }
            catch (Exception e)
            {
                return this.StatusCode(500, e);
            }
        }

        [HttpPost]
        [Route("/api/Mission/DeleteTrial/{id}")]
        public IActionResult DeleteTrial(int id)
        {
            try
            {
                return this.Ok(this.MissionService.DeleteTrial(id));
            }
            catch (Exception e)
            {
                return this.StatusCode(500, e);
            }
        }

        [HttpPost]
        [Route("/api/Mission/EditTrials")]
        public IActionResult EditTrials(EditedTrialViewModel newTrial)
        {
            try
            {
                var trial = new Trial
                {
                    Id = newTrial.Id,
                    Libelle = newTrial.Libelle,
                    MissionId = newTrial.MissionId,
                    Score = newTrial.Score,
                    CorrectAnswer = newTrial.CorrectAnswer,
                    Answers = newTrial.Answers.ToList()
                };
                this.MissionService.EditTrials(trial);
                return this.Ok("Done.");
            }
            catch (Exception e)
            {
                return this.StatusCode(500, e);
            }
        }

         /// <summary>
        /// Recover the missions of a step
        /// </summary>
        /// <param name="idstep">Id of the step</param>
        /// <returns>Missions of the step</returns>
        [Route("/api/Mission/Step/{idstep}")]
        public IActionResult Get(int idstep)
        
        {
            try
            {
                return Ok(MissionService.GetStepMission(idstep));
            }
            catch (Exception e)
            {
                return StatusCode(500, e);
            }
        }
    }
}