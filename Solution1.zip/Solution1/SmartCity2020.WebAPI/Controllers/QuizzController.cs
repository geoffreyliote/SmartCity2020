﻿// <copyright file="QuizzController.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.WebAPI.Controllers
{
    using System;
    using Microsoft.AspNetCore.Mvc;
    using Newtonsoft.Json;
    using SmartCity2020.Business.Contract;

    /// <summary>
    /// Controller which allow to get data of quiz.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class QuizzController : ControllerBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="QuizzController"/> class.
        /// </summary>
        /// <param name="quizzService">Quiz service.</param>
        public QuizzController(IQuizzService quizzService)
        {
            this.QuizzService = quizzService;
        }

        /// <summary>
        /// Gets or sets the quiz service.
        /// </summary>
        public IQuizzService QuizzService { get; set; }

        /// <summary>
        /// Allow to get the trials of a step.
        /// </summary>
        /// <param name="id">Id of the step.</param>
        /// <returns>A status with data.</returns>
        [Route("/api/Quizz/Step/{id}")]
        public IActionResult GetTrials(int id)
        {
            try
            {
                string json = JsonConvert.SerializeObject(
                    this.QuizzService.GetTrials(id), 
                    Formatting.Indented,
                    new JsonSerializerSettings
                    {
                        ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                    });
                return this.Ok(json);
            }
            catch (Exception e)
            {
                return this.StatusCode(500, e);
            }
        }
    }
}