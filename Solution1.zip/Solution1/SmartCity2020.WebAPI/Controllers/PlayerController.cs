﻿

namespace SmartCity2020.WebAPI.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using JWT;
    using JWT.Serializers;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using SmartCity2020.Business.Contract;

    [Route("api/[controller]")]
    [ApiController]
    public class PlayerController : ControllerBase
    {
        public IPlayerService PlayerService { get; set; }
        private string secret = "GQDstcKsx0NHjPOuXOYg5MbeJ1XT0uFiwDVvVBrk";

        public PlayerController(IPlayerService playerService)
        {
            PlayerService = playerService;
        }

        [Route("/api/Player/{id}")]
        public IActionResult Get(int id)
        {
            try
            {
                return Ok(PlayerService.GetInfo(id));
            }
            catch (Exception e)
            {

                return StatusCode(500, e);
            }
        }
        [Route("/api/PlayerLogin/{token}")]
        public IActionResult Login(string token)
        {
            try
            {
                IBase64UrlEncoder urlEncoder = new JwtBase64UrlEncoder();
                IJsonSerializer serializer = new JsonNetSerializer();
                IDateTimeProvider provider = new UtcDateTimeProvider();
                IJwtValidator validator = new JwtValidator(serializer, provider);
                IJwtDecoder decoder = new JwtDecoder(serializer, validator, urlEncoder);
                var payload = decoder.DecodeToObject<IDictionary<string, object>>(token, secret, verify: true);
                try
                {
                    return Ok(PlayerService.Login(payload["Username"].ToString(), payload["Password"].ToString()));
                }
                catch (Exception e)
                {

                    return Ok(0);
                }

            }
            catch (TokenExpiredException e)
            {
                Console.WriteLine("Token has expired");
                return StatusCode(500, e);
            }
            catch (SignatureVerificationException e)
            {
                Console.WriteLine("Token has invalid signature");
                return StatusCode(500, e);
            }
        }
    }
}