﻿// <copyright file="TeamController.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.WebAPI.Controllers
{
    using System;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.EntityFrameworkCore;
    using SmartCity2020.Business.Contract;
    using Newtonsoft.Json;

    /// <summary>
    /// Controller which allow to get data of team.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class TeamController : ControllerBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TeamController"/> class.
        /// </summary>
        /// <param name="teamService">Team service.</param>
        public TeamController(ITeamService teamService)
        {
            this.TeamService = teamService;
        }

        /// <summary>
        /// Gets or sets the team service.
        /// </summary>
        public ITeamService TeamService { get; set; }

        /// <summary>
        /// Allows to get the current team of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A status code with data.</returns>
        [Route("/api/Player/{id}/CurrentTeam")]
        public IActionResult GetTeam(int id)
        {
            try
            {
                return this.Ok(this.TeamService.GetTeam(id));
            }
            catch (Exception e)
            {
                return this.StatusCode(500, e);
            }
        }

        /// <summary>
        /// Allows to get the list of players of the current team of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A status code and data.</returns>
        [Route("/api/Team/{id}/Players")]
        public IActionResult GetPlayers(int id)
        {
            try
            {
                return this.Ok(this.TeamService.GetPlayers(id));
            }
            catch (Exception e)
            {
                return this.StatusCode(500, e);
            }
        }

        /// <summary>
        /// Allows to get the captain of the current team of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A player corresponding to the captain.</returns>
        [Route("/api/Player/{id}/CurrentTeam/Captain")]
        public IActionResult GetCaptain(int id)
        {
            try
            {
                return this.Ok(this.TeamService.GetCaptain(id));
            }
            catch (Exception e)
            {
                return this.StatusCode(500, e);
            }
        }

        /// <summary>
        /// Allow to check if the answer is correct and give points to the team if it is correct.
        /// </summary>
        /// <param name="answerId">Id of the answer.</param>
        /// <param name="teamId">Id of the team</param>
        /// <param name="trialId">Id of the trial.</param>
        /// <returns>A status code corresponding.</returns>
        [Route("/api/Team/CheckAnswer/{teamId}/{trialId}/{answerId}")]
        public IActionResult CheckAnswer(int answerId, int teamId, int trialId)
        {
            try
            {
                this.TeamService.CheckAnswer(answerId, teamId, trialId);
                return this.Ok("Done");
            }
            catch (Exception e)
            {
                return this.StatusCode(500, e);
            }
        }

        /// <summary>
        /// Get the list of teams
        /// </summary>
        /// <param name="answerId">Id of the answer.</param>        
        /// <returns>A status code corresponding.</returns>
        [Route("/api/Team")]
        public IActionResult GetTeams()
        {
            try
            {
                string json = JsonConvert.SerializeObject(this.TeamService.GetTeams(), Formatting.Indented, new JsonSerializerSettings
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
                return this.Ok(json);
            }
            catch (Exception e)
            {
                return this.StatusCode(500, e);
            }
        }

    }
}