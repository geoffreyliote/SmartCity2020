﻿// <copyright file="StatController.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.WebAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using Newtonsoft.Json;
    using SmartCity2020.Business.Contract;
    using System;

    /// <summary>
    /// Controller which allow to get data while using routes.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class StatController : ControllerBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StatController"/> class.
        /// </summary>
        /// <param name="statService">Stat service.</param>
        public StatController(IStatService statService)
        {
            StatService = statService;
        }

        /// <summary>
        /// Gets or sets the stat service.
        /// </summary>
        public IStatService StatService { get; set; }

        /// <summary>
        /// Allow to gets stats about the current team with the following route.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>Stats about the desired team.</returns>
        [Route("/api/Stats/Player/{id}/CurrentTeam")]
        public IActionResult GetStats(int id)
        {
            try
            {
                string json = JsonConvert.SerializeObject(StatService.GetStats(id), Formatting.Indented, new JsonSerializerSettings
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
                return Ok(json);
            }
            catch (Exception e)
            {
                return StatusCode(500, e);
            }
        }

        /// <summary>
        /// Allow to gets sscores of all teams with the following route.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>List of plays with their teams.</returns>
        [Route("/api/Stats/Player/{id}/CurrentGame")]
        public IActionResult GetTeamsScores(int id)
        {
            try
            {
                string json = JsonConvert.SerializeObject(StatService.GetTeamsScores(id), Formatting.Indented, new JsonSerializerSettings
                { 
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore 
                });

                return Ok(json);
            }
            catch (Exception e)
            {
                return StatusCode(500, e);
            }
        }
    }
}