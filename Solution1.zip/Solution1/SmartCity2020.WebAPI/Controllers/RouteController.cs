﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SmartCity2020.Business.Contract;
using SmartCity2020.Entities;

namespace SmartCity2020.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RouteController : ControllerBase
    {
        public IRouteService _routeService { get; set; }

        public RouteController(IRouteService routeService)
        {
            _routeService = routeService;
        }

        public IActionResult Get()
        {
            try
            {
                return Ok(_routeService.GetRoutes().Select(r => new
                {
                    r.Id,
                    r.Name,
                    r.Description,
                    r.Distance,
                    r.Handicap
                }));
            }
            catch (Exception e)
            {

                return StatusCode(500, e);
            }
        }
        
    }

}