﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SmartCity2020.Business.Contract;

namespace SmartCity2020.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GameController : ControllerBase
    {
        public IGameService GameService { get; set; }

        public GameController(IGameService gameService)
        {
            GameService = gameService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var result = GameService.GetGames().Select(s => new
                {
                    id = s.Id,
                    name = s.Route.Name + " " + s.CreationDate,
                    transport = s.Transport.Libelle,
                    organizer = s.Organizer.FirstName + " " + s.Organizer.LastName,
                    route = s.Route.Name,

                });
                return Ok(result);
            }
            catch (Exception e)
            {

                return StatusCode(500, e);
            }
        }
        [HttpGet]
        [Route("/api/Game/organizer/{id}")]
        public IActionResult GetActiveGames(int id)
        {
            try
            {
                return Ok(GameService.GetActiveGame(id).Select(s => new
                {
                    id = s.Id,
                    name = s.Route.Name + " " + s.CreationDate,
                    transport = s.Transport.Libelle,
                    organizer = s.Organizer.FirstName + " " + s.Organizer.LastName,
                    route = s.Route.Name,
                }));
            }
            catch (Exception e)
            {

                return StatusCode(500, e);
            }
        }
        [HttpGet]
        [Route("/api/Game/{id}/Teams")]
        public IActionResult GetGameTeams(int id)
        {
            try
            {
                string json = JsonConvert.SerializeObject(GameService.GetTeamplayers(id), Formatting.Indented, new JsonSerializerSettings
                {
                    ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });
                return Ok(json);
            }
            catch (Exception)
            {

                return StatusCode(500);
            }
        }
        [HttpGet]
        [Route("/api/Game/{id}/Progress")]
        public IActionResult GetGameProgression(int id)
        {
            try
            {
                return Ok(GameService.GetGameProgression(id));
            }
            catch (Exception)
            {

                return StatusCode(500);
            }
        }
        [HttpGet]
        [Route("/api/Game/{id}/Steps")]
        public IActionResult GetGameSteps(int id)
        {
            try
            {
               return Ok(GameService.GetStepsOfGame(id));
            }
            catch (Exception r)
            {

                return StatusCode(500, r);
            }
        }
    }
}