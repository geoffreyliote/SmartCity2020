﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Plugin.Media.Abstractions;
using SmartCity2020.Business;
using SmartCity2020.Business.Contract;
using SmartCity2020.Entities;

namespace SmartCity2020.WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StepController : ControllerBase
    {
        public IStepService StepService { get; set; }

        public StepController(IStepService stepService)
        {
            StepService = stepService;
        }

        [Route("/api/step/validation/{id}/{uploadedImageName}/{idTeam}")]
        public async Task<IActionResult> ValidationAsync(int idTeam , int id, string uploadedImageName)
        {

            try
            {
                var result = await StepService.ValidateStepAsync(idTeam ,id, uploadedImageName);
                return Ok(result);
            }
            catch (Exception e)
            {

                return StatusCode(500, e);
            }
        }
        public IActionResult Get()
        {
            try
            {
                return Ok(StepService.GetSteps());
            }
            catch (Exception e)
            {

                return StatusCode(500, e);
            }
        }
        [Route("/api/Step/{id}")]
        public IActionResult GetStep(int id)
        {
            try
            {
                return Ok(StepService.GetStep(id));
            }
            catch (Exception e)
            {

                return StatusCode(500, e);
            }
        }
        [Route("/api/Step/Player/{id}/CurrentTeam/CurrentStep")]
        public IActionResult GetTeam(int id)
        {
            try
            {
                return Ok(StepService.GetCurrentStep(id));
            }
            catch (Exception e)
            {
                return StatusCode(500, e);
            }
        }
        [HttpGet]
        [Route("/api/Step/ValidateQuizz/{id}")]
        public IActionResult ValidateQuizz(int id)
        {
            try
            {
                StepService.QuizzValidation(id);
                return Ok("Done");
            }
            catch (Exception e)
            {
                return StatusCode(500, e);
            }
        }
        [Route("/api/Step/Create")]
        public IActionResult Post([FromBody] Step step)
        {
            try
            {
                StepService.PostStep(step);
                return Ok("Done");
            }
            catch (Exception e)
            {
                return StatusCode(500, e);

            }
        }
        [Route("/api/Step/Edit/{id}")]
        public IActionResult PostEdit([FromBody] Step step, int id)
        {
            try
            {
                step.Id = id;
                StepService.EditStep(step);
                return Ok("Done");
            }
            catch (Exception e)
            {
                return StatusCode(500, e);

            }
        }
        [Route("/api/Step/DeleteStep/{id}")]
        public IActionResult Post(int id)
        {
            try
            {
                return Ok(StepService.DeleteStep(id));
            }
            catch (Exception e)
            {

                return StatusCode(500, e);
            }
        }

    }
   
}
