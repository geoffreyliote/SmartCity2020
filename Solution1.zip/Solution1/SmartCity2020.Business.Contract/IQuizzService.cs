﻿// <copyright file="IQuizzService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Business.Contract
{
    using System.Collections.Generic;
    using SmartCity2020.Entities;

    /// <summary>
    /// Interface which link the quiz service to the controllers.
    /// </summary>
    public interface IQuizzService
    {
        /// <summary>
        /// Gets all trials corresponding to the step.
        /// </summary>
        /// <param name="id">Id of the step.</param>
        /// <returns>A list of <see cref="Trial"/>.</returns>
        List<Trial> GetTrials(int id);
    }
}
