﻿// <copyright file="IStepService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Business.Contract
{
    using SmartCity2020.Entities;
    using SmartCity2020.Entities;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Interface which link the step service to the controllers.
    /// </summary>
    public interface IStepService
    {
        /// <summary>
        /// Gets a boolean which define if the step is validated or not.
        /// </summary>
        /// <returns>A boolean.</returns>
        Task<string> ValidateStepAsync(int idTeam, int idStep,string uploadedImageName);
        /// <summary>
        /// Gets the current step of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A <see cref="Step"/>.</returns>
        Step GetCurrentStep(int id);

        string DeleteStep(int id);

        /// <summary>
        /// Make the validation of a quiz.
        /// </summary>
        /// <param name="id">Id of the team. </param>
        void QuizzValidation(int id);
        /// <summary>
        /// Get all the existing routes
        /// </summary>
        /// <returns></returns>
        IEnumerable<Step> GetSteps();
        Step GetStep(int id);

        void PostStep(Step step);
        void EditStep(Step step);

        void PostPicture(FileStream fileStream);



    }
}
