﻿// <copyright file="ITeamService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Business.Contract
{
    using System.Collections.Generic;
    using SmartCity2020.Entities;

    /// <summary>
    /// Interface which link the quiz service to the controllers.
    /// </summary>
    public interface ITeamService
    {
        /// <summary>
        /// Gets the current team of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A <see cref="Team"/>.</returns>
        Team GetTeam(int id);

        /// <summary>
        /// Gets the players of the current team.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A list of <see cref="Player"/>.</returns>
        List<Player> GetPlayers(int id);

        /// <summary>
        /// Gets the captain of the current team of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A <see cref="Player"/>.</returns>
        Player GetCaptain(int id);

        /// <summary>
        /// Check if the team answer is correct or no and update score depending on it.
        /// </summary>
        /// <param name="answerId">Id of the answer.</param>
        /// <param name="teamId">Id of the team.</param>
        /// <param name="trialId">Id of the trial.</param>
        void CheckAnswer(int answerId, int teamId, int trialId);

        /// <summary>
        /// Get the list of teams.
        /// </summary>
        List<Team> GetTeams();
    }
}
