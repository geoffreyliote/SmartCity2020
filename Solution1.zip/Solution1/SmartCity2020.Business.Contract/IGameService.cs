﻿// <copyright file="IGameService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Business.Contract
{  
    using System.Collections.Generic;
    using SmartCity2020.Entities;

    /// <summary>
    /// Service interface for a game.
    /// </summary>
    public interface IGameService
    {
        /// <summary>
        /// Return all the games
        /// </summary>
        /// <returns>Return a set of games</returns>
        IEnumerable<Game> GetGames();

        /// <summary>
        /// Get the actives games attributed to the organizer that made the request
        /// </summary>
        /// <param name="id">Identifier of the organizer that made the request</param>
        /// <returns>Return all actives games</returns>
        IEnumerable<Game> GetActiveGame(int id);

        /// <summary>
        /// Get the Players of the teams playing the game 
        /// </summary>
        /// <param name="id">Identifier of the organizer that made the request</param>
        /// <returns>Return the teams of the game</returns>
        IEnumerable<Team> GetTeamplayers(int id);

        /// <summary>
        /// Get the completion of the steps for each teams for a game
        /// </summary>
        /// <param name="id">Identifier of the organizer that made the request</param>
        /// <returns>Return a custom made object with information of the team the step the order and if it has been completed</returns>
        object GetGameProgression(int id);

        /// <summary>
        /// Get all of the steps for a game
        /// </summary>
        /// <param name="id">Identifier of the game that you are looking for</param>
        /// <returns>Return a list of steps</returns>
        List<Step> GetStepsOfGame(int id);
    }
}
