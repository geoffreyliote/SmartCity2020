﻿// <copyright file="IGameService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Business.Contract
{
    using System.Collections.Generic;
    using SmartCity2020.Entities;
    public interface IRouteService
    {
        /// <summary>
        /// Get all the existing routes
        /// </summary>
        /// <returns></returns>
        IEnumerable<Route> GetRoutes();
        /// <summary>
        /// Get all the route created by a specific organizer
        /// </summary>
        /// <param name="organizerId">id of the organizer</param>
        /// <returns></returns>
        IEnumerable<Route> GetRoutesByOrganizer(int organizerId);
        /// <summary>
        /// Get the route of a game
        /// May be unused since you can get them from the game itself but in the case of emergency, it exist
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Route GetRouteForGame(int id);

    }
}
