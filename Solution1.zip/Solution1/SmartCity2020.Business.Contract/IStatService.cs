﻿// <copyright file="IStatService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Business.Contract
{
    using System.Collections.Generic;
    using SmartCity2020.Entities;

    /// <summary>
    /// Interface which link the stat service to the controllers.
    /// </summary>
    public interface IStatService
    {
        /// <summary>
        /// Gets stats about the current game.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A <see cref="TeamInfo"/>.</returns>
        TeamInfo GetStats(int id);

        /// <summary>
        /// Gets scores of all teams participating to the current game.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A list of <see cref="Play"/>.</returns>
        List<Play> GetTeamsScores(int id);
    }
}
