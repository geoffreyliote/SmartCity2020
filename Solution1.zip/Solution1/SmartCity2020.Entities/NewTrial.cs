﻿
namespace SmartCity2020.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class NewTrial
    {
        public string Libelle { get; set; }

        public string MissionId { get; set; }

        public string Score { get; set; }

        public IEnumerable<string> Answers { get; set; }

        public string CorrectAnswer { get; set; }
    }
}
