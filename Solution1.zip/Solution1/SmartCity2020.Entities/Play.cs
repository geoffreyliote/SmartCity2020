﻿// <copyright file="Play.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Entities
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to a link between game and team.
    /// </summary>
    public partial class Play
    {
        /// <summary>
        /// Gets or sets the identifier of the <see cref="Game"/>.
        /// </summary>
        public int GameId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Team"/>.
        /// </summary>
        public int TeamId { get; set; }

        /// <summary>
        /// Gets or sets the score made by the team for the game.
        /// </summary>
        public int? Score { get; set; }

        /// <summary>
        /// Gets or sets the start date of the team for the game.
        /// </summary>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Gets or sets the end date of the team for the game.
        /// </summary>
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Gets or sets the time done by the team for the game.
        /// </summary>
        public TimeSpan? Time { get; set; }

        /// <summary>
        /// Gets or sets the game linked to the <see cref="GameId"/>.
        /// </summary>
        public virtual Game Game { get; set; }

        /// <summary>
        /// Gets or sets the team linked to the <see cref="TeamId"/>.
        /// </summary>
        public virtual Team Team { get; set; }
    }
}
