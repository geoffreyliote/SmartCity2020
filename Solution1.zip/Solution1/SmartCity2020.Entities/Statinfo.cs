﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartCity2020.Entities
{
    public partial class Statinfo
    {
      public int NbStepGame { get; set; }
      public int NbStepTeam { get; set; }
      public int ScoreTeam { get; set; }
      public int NbAnswerGame { get; set; }
      public int NbAnswerTeam { get; set; }
    }
}
