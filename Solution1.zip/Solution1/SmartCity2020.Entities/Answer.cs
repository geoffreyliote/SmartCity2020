﻿// <copyright file="Answer.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Entities
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to an answer.
    /// </summary>
    public partial class Answer
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Answer"/> class.
        /// </summary>
        public Answer()
        {
            this.Teamanswers = new HashSet<Teamanswer>();
            this.Trials = new HashSet<Trial>();
        }

        /// <summary>
        /// Gets or sets the identifier of the answer.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the trial corresponding to an answer.
        /// </summary>
        public int? TrialId { get; set; }

        /// <summary>
        /// Gets or sets the label of the answer.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Gets or sets the picture of the answer.
        /// </summary>
        public string Picture { get; set; }

        /// <summary>
        /// Gets or sets the trial corresponding to <see cref="TrialId"/>.
        /// </summary>
        public virtual Trial Trial { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Teamanswer"/>.
        /// </summary>
        public virtual ICollection<Teamanswer> Teamanswers { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Trial"/>.
        /// </summary>
        public virtual ICollection<Trial> Trials { get; set; }
    }
}
