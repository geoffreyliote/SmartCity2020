﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartCity2020.Entities
{
   public partial class Scoreboard
    {
    public string Teamname { get; set; }
    public string TeamScore { get; set; }
    }
}
