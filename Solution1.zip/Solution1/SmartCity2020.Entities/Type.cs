﻿// <copyright file="Type.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Entities
{
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to a type.
    /// </summary>
    public partial class Type
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Type"/> class.
        /// </summary>
        public Type()
        {
            this.Trials = new HashSet<Trial>();
        }

        /// <summary>
        /// Gets or sets the identifier of the type.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the description of the type.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Trial"/>.
        /// </summary>
        public virtual ICollection<Trial> Trials { get; set; }
    }
}
