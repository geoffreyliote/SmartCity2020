﻿// <copyright file="Routetag.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Entities
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to the link between route and tag.
    /// </summary>
    public partial class Routetag
    {
        /// <summary>
        /// Gets or sets the identifier of the <see cref="Route"/>.
        /// </summary>
        public int RouteId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Tag"/>.
        /// </summary>
        public int TagId { get; set; }

        /// <summary>
        /// Gets or sets the route linked to the <see cref="RouteId"/> seen before.
        /// </summary>
        public virtual Route Route { get; set; }

        /// <summary>
        /// Gets or sets the tag linked to the <see cref="TagId"/> seen before.
        /// </summary>
        public virtual Tag Tag { get; set; }
    }
}
