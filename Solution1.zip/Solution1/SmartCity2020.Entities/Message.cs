﻿// <copyright file="Message.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Entities
{
    using System;

    /// <summary>
    /// Class corresponding to a message.
    /// </summary>
    public partial class Message
    {
        /// <summary>
        /// Gets or sets the identifier of the message.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the player who sent the message.
        /// </summary>
        public int PlayerId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the organizer who receive the message.
        /// </summary>
        public int OrganizerId { get; set; }

        /// <summary>
        /// Gets or sets the content of the message.
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether it is an organizer or not.
        /// </summary>
        public bool FromOrganiser { get; set; }

        /// <summary>
        /// Gets or sets the date of the message.
        /// </summary>
        public DateTime? Date { get; set; }

        /// <summary>
        /// Gets or sets the organizer linked to the <see cref="OrganizerId"/>.
        /// </summary>
        public virtual Organizer Organizer { get; set; }

        /// <summary>
        /// Gets or sets the player linked to the <see cref="Player"/>.
        /// </summary>
        public virtual Player Player { get; set; }
    }
}
