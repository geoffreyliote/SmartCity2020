﻿// <copyright file="Teamanswer.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Entities
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to the link between team and answer.
    /// </summary>
    public partial class Teamanswer
    {
        /// <summary>
        /// Gets or sets the identifier of the <see cref="Team"/>.
        /// </summary>
        public int TeamId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Game"/>.
        /// </summary>
        public int GameId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Trial"/>.
        /// </summary>
        public int TrialId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Answer"/>.
        /// </summary>
        public int AnswerId { get; set; }

        /// <summary>
        /// Gets or sets the text contained in the answer.
        /// </summary>
        public string TextAnswer { get; set; }

        /// <summary>
        /// Gets or sets the date when team answered.
        /// </summary>
        public DateTime? Date { get; set; }

        /// <summary>
        /// Gets or sets a value whether the answer is true or false.
        /// </summary>
        public bool? Good { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the team answer.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the answer corresponding to the <see cref="AnswerId"/>.
        /// </summary>
        public virtual Answer Answer { get; set; }

        /// <summary>
        /// Gets or sets the game corresponding to the <see cref="GameId"/>.
        /// </summary>
        public virtual Game Game { get; set; }

        /// <summary>
        /// Gets or sets the team corresponding to the <see cref="TeamId"/>.
        /// </summary>
        public virtual Team Team { get; set; }

        /// <summary>
        /// Gets or sets the trial corresponding to the <see cref="TrialId"/>.
        /// </summary>
        public virtual Trial Trial { get; set; }
    }
}
