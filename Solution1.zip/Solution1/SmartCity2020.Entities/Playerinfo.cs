﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SmartCity2020.Entities
{
    public partial class Playerinfo
    {
        public int NbOfGame { get; set; }
        public int NbOfSteps { get; set; }
        public int NbOfTeamLeader { get; set; }
        public int NbQrCodeScanned { get; set; }
        public bool IsActualTeamLeader { get; set; }
        public virtual Player Player { get; set; }

    }
}
