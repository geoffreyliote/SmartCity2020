﻿// <copyright file="Route.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Entities
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to a route.
    /// </summary>
    public partial class Route
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Route"/> class.
        /// </summary>
        public Route()
        {
            this.Games = new HashSet<Game>();
            this.Routesteps = new HashSet<Routestep>();
            this.Routetags = new HashSet<Routetag>();
        }

        /// <summary>
        /// Gets or sets the identifier of the route.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the route.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the description of the route.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets a value whether the route allow handicap or not.
        /// </summary>
        public bool? Handicap { get; set; }

        /// <summary>
        /// Gets or sets the duration of the route.
        /// </summary>
        public TimeSpan? Time { get; set; }

        /// <summary>
        /// Gets or sets the distance of the route.
        /// </summary>
        public int? Distance { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Organizer"/>.
        /// </summary>
        public int? OrganizerId { get; set; }

        /// <summary>
        /// Gets or sets the organizer linked to the <see cref="OrganizerId"/>.
        /// </summary>
        public virtual Organizer Organizer { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Game"/>.
        /// </summary>
        public virtual ICollection<Game> Games { get; set; }

        /// <summary>
        /// Gets or sets the link with steps.
        /// </summary>
        public virtual ICollection<Routestep> Routesteps { get; set; }

        /// <summary>
        /// Gets or sets the link with tags.
        /// </summary>
        public virtual ICollection<Routetag> Routetags { get; set; }
    }
}
