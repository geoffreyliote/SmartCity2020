﻿// <copyright file="Step.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Entities
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to a step.
    /// </summary>
    public partial class Step
    {
        /// <summary>
        /// Initializes a new instance of <see cref="Step"/>.
        /// </summary>
        public Step()
        {
            this.Missions = new HashSet<Mission>();
            this.Routesteps = new HashSet<Routestep>();
        }

        /// <summary>
        /// Gets or sets the identifier of the step.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the description of the step.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the validation picture of the step.
        /// </summary>
        public string Validation { get; set; }

        /// <summary>
        /// Gets or sets the creation date of the step.
        /// </summary>
        public DateTime? CreationDate { get; set; }

        /// <summary>
        /// Gets or sets the name of the step.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the latitude of the step.
        /// </summary>
        public double? Lat { get; set; }

        /// <summary>
        /// Gets or sets the longitude of the step.
        /// </summary>
        public double? Lng { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Mission"/>
        /// </summary>
        public virtual ICollection<Mission> Missions { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Routestep"/>
        /// </summary>
        public virtual ICollection<Routestep> Routesteps { get; set; }
    }
}
