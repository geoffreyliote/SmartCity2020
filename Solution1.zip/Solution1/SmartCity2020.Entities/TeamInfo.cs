﻿// <copyright file="TeamInfo.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Entities
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// Class containing information about a team.
    /// </summary>
    public class TeamInfo
    {
        /// <summary>
        /// Gets or sets which step is actually in progress on every step of this game.
        /// </summary>
        public int StepsDone { get; set; }

        /// <summary>
        /// Gets or sets the total number of steps to do in this game.
        /// </summary>
        public int AllSteps { get; set; }

        /// <summary>
        /// Gets or sets the number of points obtained by the team.
        /// </summary>
        public int CurrentPoints { get; set; }

        /// <summary>
        /// Gets or sets the number of answered questions by the team.
        /// </summary>
        public int AnsweredQuestions { get; set; }

        /// <summary>
        /// Gets or sets the total number of questions.
        /// </summary>
        public int TotalQuestions { get; set; }
    }
}
