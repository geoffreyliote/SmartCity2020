﻿// <copyright file="StepService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
namespace SmartCity2020.Services
{
    using System.Net.Http;
    using Newtonsoft.Json;
    using SmartCity2020.Models;

    /// <summary>
    /// Service for the step part of the application.
    /// </summary>
    public class StepService : IStepService
    {
        /// <summary>
        /// Use for API calls.
        /// </summary>
        private static readonly HttpClient Client = new HttpClient();

        /// <summary>
        /// Get information about the current step.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>Result of the API request.</returns>
        public Step GetCurrentStep(int id)
        {
            return JsonConvert.DeserializeObject<Step>(Client.GetStringAsync(App.ApiBaseUrl + "Step/Player/" + id + "/CurrentTeam/CurrentStep").Result);
        }
    }
}
