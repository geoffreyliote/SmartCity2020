﻿// <copyright file="StatService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
namespace SmartCity2020.Services
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Text;
    using Newtonsoft.Json;
    using SmartCity2020.Entities;
    using SmartCity2020.Models;

    /// <summary>
    /// Service which get stats about the current game.
    /// </summary>
    public class StatService : IStatService
    {
        /// <summary>
        /// Http client that we use to communicate with the API.
        /// </summary>
        private static readonly HttpClient Client = new HttpClient();

        /// <summary>
        /// Gets stats about the current game.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A <see cref="TeamInfo"/> containing stats.</returns>
        public TeamInfo GetStats(int id) => JsonConvert.DeserializeObject<TeamInfo>(Client.GetStringAsync(App.ApiBaseUrl + "Stats/Player/" + id + "/CurrentTeam").Result);

        /// <summary>
        /// Gets scores of all teams of the current game of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A list of <see cref="Play"/>.</returns>
        public List<Play> GetTeamsScores(int id) => JsonConvert.DeserializeObject<List<Play>>(Client.GetStringAsync(App.ApiBaseUrl + "Stats/Player/" + id + "/CurrentGame").Result);
    }
}
