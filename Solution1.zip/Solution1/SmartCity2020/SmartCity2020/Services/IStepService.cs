﻿// <copyright file="IStepService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
namespace SmartCity2020.Services
{
    using SmartCity2020.Models;

    /// <summary>
    /// Interface of the services corresponding to the step that we want.
    /// </summary>
    public interface IStepService
    {
        /// <summary>
        /// Get the current step of the current game of the selected player.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>The current step.</returns>
        Step GetCurrentStep(int id);
    }
}
