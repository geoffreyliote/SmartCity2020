﻿// <copyright file="QuizzService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
namespace SmartCity2020.Services
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Text;
    using Newtonsoft.Json;
    using SmartCity2020.Models;

    /// <summary>
    /// Services which corresponds to quiz.
    /// </summary>
    public class QuizzService : IQuizzService
    {
        /// <summary>
        /// Http client that we use to communicate with the API.
        /// </summary>
        private static readonly HttpClient Client = new HttpClient();

        /// <summary>
        /// Get trials (questions) corresponding to the current step.
        /// </summary>
        /// <param name="id">Id of the current step.</param>
        /// <returns>The list of trials for the current step.</returns>
        public List<Trial> GetTrials(int id) => JsonConvert.DeserializeObject<List<Trial>>(Client.GetStringAsync(App.ApiBaseUrl + "Quizz/Step/" + id).Result);

        /// <summary>
        /// Validation of a step after quiz.
        /// </summary>
        /// <param name="id">Step concerned.</param>
        public void ValidateStep(int id)
        {
            HttpResponseMessage message = Client.GetAsync(App.ApiBaseUrl + "Step/ValidateQuizz/" + id).Result;
        }

        /// <summary>
        /// Send a request to the API to check if the answer is correct.
        /// </summary>
        /// <param name="answerId">Id of the concerned answer.</param>
        /// <param name="teamId">Id of the concerned team.</param>
        /// <param name="trialId">Id of the concerned trial.</param>
        public void CheckAnswer(int answerId, int teamId, int trialId)
        {
            HttpResponseMessage message = Client.GetAsync(App.ApiBaseUrl + "Team/CheckAnswer/" + teamId + "/" + trialId + "/" + answerId).Result;
        }
    }
}
