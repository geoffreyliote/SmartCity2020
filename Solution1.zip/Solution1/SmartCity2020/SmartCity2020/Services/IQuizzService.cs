﻿// <copyright file="IQuizzService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
namespace SmartCity2020.Services
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using SmartCity2020.Models;

    /// <summary>
    /// Interface corresponding to the communication between quiz service and view model.
    /// </summary>
    public interface IQuizzService
    {
        /// <summary>
        /// Initializes the method to get trials corresponding to the step.
        /// </summary>
        /// <param name="id">Id of the step.</param>
        /// <returns>A list of <see cref="Trial"/>.</returns>
        List<Trial> GetTrials(int id);

        /// <summary>
        /// Initializes the method to validate the step in progress.
        /// </summary>
        /// <param name="id">Id of the step.</param>
        void ValidateStep(int id);

        /// <summary>
        /// Initializes the method to check if team answer is the correct one.
        /// </summary>
        /// <param name="answerId">Id of the answer.</param>
        /// <param name="teamId">Id of the team.</param>
        /// <param name="trialId">Id of the trial.</param>
        void CheckAnswer(int answerId, int teamId, int trialId);
    }
}
