﻿//-----------------------------------------------------------------------
// <copyright file="PlayerService.cs" company="Diiage">
//     Company copyright tag.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
//-----------------------------------------------------------------------
namespace SmartCity2020.Services
{
    using System.Net.Http;
    using Newtonsoft.Json;
    using SmartCity2020.Models;

    /// <summary>
    /// Service which manage Player, inherit from the Interface IPlayerService.
    /// </summary>
    public class PlayerService : IPlayerService
    {
        /// <summary>
        /// Use for API calls.
        /// </summary>
        private static readonly HttpClient Client = new HttpClient();

        /// <summary>
        /// Call the API and return the player corresponding to the id.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A <see cref="Player"/> corresponding to the id.</returns>
        public Player GetPlayer(int id)
        {
            return JsonConvert.DeserializeObject<Player>(Client.GetStringAsync(App.ApiBaseUrl + "Player" + id).Result);
        }

        /// <summary>
        /// Get information about a player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A <see cref="Playerinfo"/>.</returns>
        Playerinfo IPlayerService.GetInfo(int id)
        {
            return JsonConvert.DeserializeObject<Playerinfo>(Client.GetStringAsync(App.ApiBaseUrl + "Player/" + id).Result);
        }

        /// <summary>
        /// Make connection of the player.
        /// </summary>
        /// <param name="token">Connection token.</param>
        /// <returns>Player id.</returns>
        int IPlayerService.Login(string token) => JsonConvert.DeserializeObject<int>(Client.GetStringAsync(App.ApiBaseUrl + "PlayerLogin/" + token).Result);
    }
}
