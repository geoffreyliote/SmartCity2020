﻿//-----------------------------------------------------------------------
// <copyright file="IPlayerService.cs" company="Diiage">
//     Company copyright tag.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
//-----------------------------------------------------------------------
namespace SmartCity2020.Services
{
    using System.Collections.Generic;
    using SmartCity2020.Models;

    /// <summary>
    /// Documentation for interface IPlayerService.
    /// </summary>
    public interface IPlayerService
    {
        /// <summary>
        /// Get information of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>Information about the player.</returns>
        Playerinfo GetInfo(int id);

        /// <summary>
        /// Make customer's connection.
        /// </summary>
        /// <param name="token">JWT token.</param>
        /// <returns>Player id.</returns>
        int Login(string token);
    }
}
