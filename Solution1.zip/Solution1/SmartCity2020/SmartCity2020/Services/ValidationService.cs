﻿// <copyright file="ValidationService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
namespace SmartCity2020.Services
{
    using System;
    using System.Net.Http;
    using System.Threading.Tasks;
    using Amazon;
    using Amazon.S3;
    using Amazon.S3.Model;
    using Newtonsoft.Json;
    using SmartCity2020.Models;
    using Xamarin.Essentials;

    /// <summary>
    /// Service which communicate with the API to manage validation.
    /// </summary>
    public class ValidationService : IValidationService
    {
        /// <summary>
        /// Initializes a new HttpClient.
        /// </summary>
        private static readonly HttpClient Client = new HttpClient();

        /// <summary>
        /// Upload image on the AWS bucket.
        /// </summary>
        /// <param name="filepath">Path of the image.</param>
        /// <returns>Name of the image.</returns>
        async Task<string> IValidationService.UploadImage(string filepath)
        {
            var nameStep = JsonConvert.DeserializeObject<Step>(ValidationService.Client.GetStringAsync(App.ApiBaseUrl + "Step/Player/" + App.IdConnectedPlayer + "/CurrentTeam/CurrentStep").Result);
            string imageName = "step" + nameStep.Name + ",stepId" + App.CurrentStepId + ",idPlayer" + App.IdConnectedPlayer + ",idTeam" + App.CurrentTeamId + ".jpg";
            var client = new AmazonS3Client("AKIASTDT7K7NXMPWR5RW", "ujQp/IUAklRDJcfHkO3XRLEYZzB4+IUXka4fWfkb", RegionEndpoint.USEast1);
            var putRequest = new PutObjectRequest
            {
                BucketName = "tagsverification",
                Key = imageName,
                FilePath = filepath,
                ContentType = "text/plain"
            };
             
            PutObjectResponse response = await client.PutObjectAsync(putRequest);
            return imageName;
        }

        /// <summary>
        /// Check the picture that we send get the state (correct or not).
        /// </summary>
        /// <param name="idTeam">Id of the team which wants to check picture.</param>
        /// <param name="idStep">Id of the step corresponding to the picture (used to obtain the image of the step from the database/bucket).</param>
        /// <param name="uploadedImageName">Name of the image the user uploaded just before on the bucket.</param>
        /// <returns>State of the validation.</returns>
        async Task<string> IValidationService.CheckPhoto(int idTeam, int idStep, string uploadedImageName)
        {
            string result;
             
            try
            {
                result = await Client.GetStringAsync(App.ApiBaseUrl + "Step/validation/" + idStep + "/" + uploadedImageName);
            }
            catch (Exception e)
            {
                throw e;
            }

            return result;
        }

        /// <summary>
        /// Check location of the team.
        /// </summary>
        /// <returns>True if the team is at less than 100m of the step.</returns>
        async Task<bool> IValidationService.CheckGeoloc()
        {
            try
            {
                var apiResult = await Client.GetStringAsync(App.ApiBaseUrl + "Step/Player/" + App.IdConnectedPlayer + "/CurrentTeam/CurrentStep");
                Step res = JsonConvert.DeserializeObject<Step>(apiResult);

                var request = new GeolocationRequest(GeolocationAccuracy.Medium);
                var location = await Geolocation.GetLocationAsync(request);
                var distance = Xamarin.Essentials.Location.CalculateDistance((double)res.Lat, (double)res.Lng, location, DistanceUnits.Kilometers);
                if (distance <= 0.1)
                {
                    return true;
                }
                else
                {
                    await App.Current.MainPage.DisplayAlert("Hey", "You are "+distance+" km away of were you should be", "I still want to see what's next just for the demo");
                    return true;
                }
            }
            catch (FeatureNotSupportedException fnsEx)
            {
                // Handle not supported on device exception
                throw fnsEx;
            }
            catch (FeatureNotEnabledException fneEx)
            {
                // Handle not enabled on device exception
                throw fneEx;
            }
            catch (PermissionException pEx)
            {
                // Handle permission exception
                await App.Current.MainPage.DisplayAlert("Hey", "it seems like you didn't allowed us to track you .... Smart move", "yay");
                return true;
            }
            catch (Exception ex)
            {
                // Unable to get location
                throw ex;
            }
        }
    }
}