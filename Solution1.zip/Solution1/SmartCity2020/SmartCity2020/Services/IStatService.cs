﻿// <copyright file="IStatService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
namespace SmartCity2020.Services
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using SmartCity2020.Entities;
    using SmartCity2020.Models;

    /// <summary>
    /// Interface corresponding to the service which get stats about the current game.
    /// </summary>
    public interface IStatService
    {
        /// <summary>
        /// Initializes the method to get stats about the current game.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A <see cref="TeamInfo"/>.</returns>
        TeamInfo GetStats(int id);

        /// <summary>
        /// Initializes the method to get scores of all teams participating to the game.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>A list of <see cref="Play"/>.</returns>
        List<Play> GetTeamsScores(int id);
    }
}
