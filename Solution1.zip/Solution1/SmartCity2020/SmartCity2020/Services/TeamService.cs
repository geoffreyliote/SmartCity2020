﻿// <copyright file="TeamService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
namespace SmartCity2020.Services
{
    using System.Collections.Generic;
    using System.Net.Http;
    using Newtonsoft.Json;
    using SmartCity2020.Models;

    /// <summary>
    /// Service corresponding to the current team of a player.
    /// It communicate with the API to get that we want.
    /// </summary>
    public class TeamService : ITeamService
    {
        /// <summary>
        /// Http client that we use to communicate with the API.
        /// </summary>
        private static readonly HttpClient Client = new HttpClient();

        /// <summary>
        /// A get request to the API to get current team captain.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>The team captain of the current team.</returns>
        public Player GetCaptain(int id) => JsonConvert.DeserializeObject<Player>(Client.GetStringAsync(App.ApiBaseUrl + "Player/" + id + "/CurrentTeam/Captain").Result);

        /// <summary>
        /// A get request to the API to get current team members.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>The list of players of the current team.</returns>
        public List<Player> GetTeamMembers(int id) => JsonConvert.DeserializeObject<List<Player>>(Client.GetStringAsync(App.ApiBaseUrl + "Team/" + id + "/Players").Result);

        /// <summary>
        /// A get request to the API to get current team of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>The current team of the player.</returns>
        public Team GetTeam(int id) => JsonConvert.DeserializeObject<Team>(Client.GetStringAsync(App.ApiBaseUrl + "Player/" + id + "/CurrentTeam").Result);
    }
}
