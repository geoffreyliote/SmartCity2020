﻿// <copyright file="ITeamService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
namespace SmartCity2020.Services
{
    using System.Collections.Generic;
    using SmartCity2020.Models;

    /// <summary>
    /// Interface corresponding to current team.
    /// </summary>
    public interface ITeamService
    {
        /// <summary>
        /// Initializes the method to get the team captain of the current team of the player.
        /// </summary>
        /// <param name="id">The identifier of the player.</param>
        /// <returns>The captain of the team.</returns>
        Player GetCaptain(int id);

        /// <summary>
        /// Initializes the method to get the players of the current team of the player.
        /// </summary>
        /// <param name="id">The identifier of the player.</param>
        /// <returns>The list of players of the team.</returns>
        List<Player> GetTeamMembers(int id);

        /// <summary>
        /// Initializes the method to get the current team of the player.
        /// </summary>
        /// <param name="id">The identifier of the player.</param>
        /// <returns>The team corresponding to the identifier.</returns>
        Team GetTeam(int id);
    }
}
