﻿// <copyright file="IValidationService.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.Services</summary>
// <author>Team 1</author>
namespace SmartCity2020.Services
{
    using System.Threading.Tasks;

    /// <summary>
    /// Interface corresponding to the service that make the validation of a step.
    /// </summary>
    public interface IValidationService
    {
        /// <summary>
        /// Upload an image on AWS bucket.
        /// </summary>
        /// <param name="filePath">Path of the image.</param>
        /// <returns>Name of the image.</returns>
        Task<string> UploadImage(string filePath);

        /// <summary>
        /// Check the picture that we send get the state (correct or not).
        /// </summary>
        /// <param name="idTeam">Id of the team which wants to validate the step.</param>
        /// <param name="idStep">Id of the step to validate.</param>
        /// <param name="uploadedImageName">Name of the uploaded image.</param>
        /// <returns>Name of the image.</returns>
        Task<string> CheckPhoto(int idTeam, int idStep, string uploadedImageName);

        /// <summary>
        /// Get location of the player.
        /// </summary>
        /// <returns>True if player is less than 100m of the step. False if not.</returns>
        Task<bool> CheckGeoloc();
    }
}
