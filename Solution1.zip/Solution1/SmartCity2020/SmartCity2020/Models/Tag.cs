﻿// <copyright file="Tag.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to a tag.
    /// </summary>
    public partial class Tag
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Tag"/> class.
        /// </summary>
        public Tag()
        {
            this.Routetags = new List<Routetag>();
        }

        /// <summary>
        /// Gets or sets the identifier of the tag.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the description of the tag.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the color of the tag.
        /// </summary>
        public string Color { get; set; }

        /// <summary>
        /// Gets or sets the name of the tag.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Routetag"/>
        /// </summary>
        public virtual ICollection<Routetag> Routetags { get; set; }
    }
}
