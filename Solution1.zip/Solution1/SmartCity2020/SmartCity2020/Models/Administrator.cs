﻿// <copyright file="Administrator.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to an administrator of the application.
    /// </summary>
    public partial class Administrator
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Administrator"/> class.
        /// </summary>
        public Administrator()
        {
            this.Organizers = new List<Organizer>();
        }

        /// <summary>
        /// Gets or sets the identifier of the administrator.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the first name of the administrator.
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last name of the administrator.
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the login of the administrator.
        /// </summary>
        public string Login { get; set; }

        /// <summary>
        /// Gets or sets the password of the administrator.
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets the email of the administrator.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the list of organizers created by this administrator.
        /// </summary>
        public virtual ICollection<Organizer> Organizers { get; set; }
    }
}
