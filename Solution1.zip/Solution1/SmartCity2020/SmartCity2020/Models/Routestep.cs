﻿// <copyright file="Routestep.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to the link between route and step.
    /// </summary>
    public partial class Routestep
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Routestep"/> class.
        /// </summary>
        public Routestep()
        {
            this.Teamroutes = new List<Teamroute>();
        }

        /// <summary>
        /// Gets or sets the <see cref="Route"/>.
        /// </summary>
        public int RouteId { get; set; }

        /// <summary>
        /// Gets or sets the <see cref="Step"/>.
        /// </summary>
        public int StepId { get; set; }

        /// <summary>
        /// Gets or sets the order of the steps in the route.
        /// </summary>
        public int? StepOrder { get; set; }

        /// <summary>
        /// Gets or sets the route linked to the <see cref="RouteId"/>.
        /// </summary>
        public virtual Route Route { get; set; }

        /// <summary>
        /// Gets or sets the step linked to the <see cref="StepId"/>.
        /// </summary>
        public virtual Step Step { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Teamroute"/>.
        /// </summary>
        public virtual ICollection<Teamroute> Teamroutes { get; set; }
    }
}
