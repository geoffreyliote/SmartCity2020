﻿// <copyright file="Trial.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to a trial.
    /// </summary>
    public partial class Trial
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Trial"/> class.
        /// </summary>
        public Trial()
        {
            this.Answers = new List<Answer>();
            this.Teamanswers = new List<Teamanswer>();
        }

        /// <summary>
        /// Gets or sets the identifier of the trial.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Type"/>.
        /// </summary>
        public int? TypeId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Mission"/>.
        /// </summary>
        public int? MissionId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the correct <see cref="Answer"/>.
        /// </summary>
        public int? CorrectAnswerId { get; set; }

        /// <summary>
        /// Gets or sets the score of the trial.
        /// </summary>
        public int? Score { get; set; }

        /// <summary>
        /// Gets or sets the label of the trial.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Gets or sets the answer corresponding to the <see cref="CorrectAnswerId"/>.
        /// </summary>
        public virtual Answer CorrectAnswer { get; set; }

        /// <summary>
        /// Gets or sets the mission corresponding to the <see cref="MissionId"/>.
        /// </summary>
        public virtual Mission Mission { get; set; }

        /// <summary>
        /// Gets or sets the type corresponding to the <see cref="TypeId"/>.
        /// </summary>
        public virtual Type Type { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Answer"/>.
        /// </summary>
        public virtual ICollection<Answer> Answers { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Teamanswer"/>.
        /// </summary>
        public virtual ICollection<Teamanswer> Teamanswers { get; set; }
    }
}
