﻿// <copyright file="Playerinfo.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    /// <summary>
    /// Class corresponding to player's info.
    /// </summary>
    public partial class Playerinfo
    {
        /// <summary>
        /// Gets or sets the number of Games of the player.
        /// </summary>
        public int NbOfGame { get; set; }

        /// <summary>
        /// Gets or sets the number of Steps of the player.
        /// </summary>
        public int NbOfSteps { get; set; }

        /// <summary>
        /// Gets or sets the number of Time being the team Leader of the player.
        /// </summary>
        public int NbOfTeamLeader { get; set; }

        /// <summary>
        /// Gets or sets the number of QR code scanned by the player.
        /// </summary>
        public int NbQrCodeScanned { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the user is an actual Team Leader
        /// </summary>
        public bool IsActualTeamLeader { get; set; }

        /// <summary>
        /// Gets or sets the Player linked to the <see cref="PlayerId"/>.
        /// </summary>
        public virtual Player Player { get; set; }
    }
}
