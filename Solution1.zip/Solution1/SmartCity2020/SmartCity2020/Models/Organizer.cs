﻿// <copyright file="Organizer.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to an organizer.
    /// </summary>
    public partial class Organizer
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Organizer"/> class.
        /// </summary>
        public Organizer()
        {
            this.Games = new List<Game>();
            this.Messages = new List<Message>();
            this.Players = new List<Player>();
            this.Routes = new List<Route>();
            this.Teams = new List<Team>();
        }

        /// <summary>
        /// Gets or sets the identifier of the organizer.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the first name of the organizer.
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last name of the organizer.
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the login of the organizer.
        /// </summary>
        public string Login { get; set; }

        /// <summary>
        /// Gets or sets the password of the organizer.
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets the email of the organizer.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Administrator"/>.
        /// </summary>
        public int? AdministratorId { get; set; }

        /// <summary>
        /// Gets or sets the administrator linked to the <see cref="AdministratorId"/>.
        /// </summary>
        public virtual Administrator Administrator { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Game"/>.
        /// </summary>
        public virtual ICollection<Game> Games { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Message"/>.
        /// </summary>
        public virtual ICollection<Message> Messages { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Player"/>.
        /// </summary>
        public virtual ICollection<Player> Players { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Route"/>.
        /// </summary>
        public virtual ICollection<Route> Routes { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Team"/>.
        /// </summary>
        public virtual ICollection<Team> Teams { get; set; }
    }
}
