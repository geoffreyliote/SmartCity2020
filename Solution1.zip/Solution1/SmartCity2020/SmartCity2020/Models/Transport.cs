﻿// <copyright file="Transport.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to the transport.
    /// </summary>
    public partial class Transport
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Transport"/> class.
        /// </summary>
        public Transport()
        {
            this.Games = new List<Game>();
        }

        /// <summary>
        /// Gets or sets the identifier of the transport.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the label of the transport.
        /// </summary>
        public string Libelle { get; set; }

        /// <summary>
        /// Gets or sets the description of the transport.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Game"/>
        /// </summary>
        public virtual ICollection<Game> Games { get; set; }
    }
}
