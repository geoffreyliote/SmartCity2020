﻿// <copyright file="Player.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to a player.
    /// </summary>
    public partial class Player
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Player"/> class.
        /// </summary>
        public Player()
        {
            this.Messages = new List<Message>();
            this.Teams = new List<Team>();
            this.Teamplayers = new List<Teamplayer>();
        }

        /// <summary>
        /// Gets or sets the identifier of the player.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the first name of the player.
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets the last name of the player.
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets the login of the player.
        /// </summary>
        public string Login { get; set; }

        /// <summary>
        /// Gets or sets the password of the player.
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets the email of the player.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets the picture of the player.
        /// </summary>
        public string Picture { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Organizer"/>.
        /// </summary>
        public int? OrganizerId { get; set; }

        /// <summary>
        /// Gets or sets the organizer linked to the <see cref="OrganizerId"/>.
        /// </summary>
        public virtual Organizer Organizer { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Message"/>.
        /// </summary>
        public virtual ICollection<Message> Messages { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Team"/>.
        /// </summary>
        public virtual ICollection<Team> Teams { get; set; }

        /// <summary>
        /// Gets or sets the link between player and team.
        /// </summary>
        public virtual ICollection<Teamplayer> Teamplayers { get; set; }
    }
}
