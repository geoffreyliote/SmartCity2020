﻿// <copyright file="Game.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to a game.
    /// </summary>
    public partial class Game
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Game"/> class.
        /// </summary>
        public Game()
        {
            this.Plays = new List<Play>();
            this.Teamanswers = new List<Teamanswer>();
            this.Teamroutes = new List<Teamroute>();
        }

        /// <summary>
        /// Gets or sets the identifier of the game.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the linked route.
        /// </summary>
        public int? RouteId { get; set; }

        /// <summary>
        /// Gets or sets the final time of the game.
        /// </summary>
        public DateTime? FinalTime { get; set; }

        /// <summary>
        /// Gets or sets the final score of the game.
        /// </summary>
        public int? FinalScore { get; set; }

        /// <summary>
        /// Gets or sets the creation date of the game.
        /// </summary>
        public DateTime? CreationDate { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the organizer of the game.
        /// </summary>
        public int? OrganizerId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the transports corresponding to the game.
        /// </summary>
        public int? TransportId { get; set; }

        /// <summary>
        /// Gets or sets the organizer linked to the <see cref="OrganizerId"/>.
        /// </summary>
        public virtual Organizer Organizer { get; set; }

        /// <summary>
        /// Gets or sets the route linked to the <see cref="RouteId"/>.
        /// </summary>
        public virtual Route Route { get; set; }

        /// <summary>
        /// Gets or sets the transport linked to the <see cref="TransportId"/>.
        /// </summary>
        public virtual Transport Transport { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Play"/>.
        /// </summary>
        public virtual ICollection<Play> Plays { get; set; }

        /// <summary>
        /// Gets or sets the list of answers of <see cref="Teamanswer"/>.
        /// </summary>
        public virtual ICollection<Teamanswer> Teamanswers { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Teamroute"/>.
        /// </summary>
        public virtual ICollection<Teamroute> Teamroutes { get; set; }
    }
}
