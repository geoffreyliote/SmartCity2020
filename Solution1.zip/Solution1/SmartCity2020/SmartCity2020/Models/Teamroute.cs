﻿// <copyright file="Teamroute.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System;

    /// <summary>
    /// Class corresponding to a link between team and route.
    /// </summary>
    public partial class Teamroute
    {
        /// <summary>
        /// Gets or sets the identifier of the <see cref="Game"/>
        /// </summary>
        public int GameId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Team"/>
        /// </summary>
        public int TeamId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Route"/>
        /// </summary>
        public int? RouteId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="RouteStep"/>
        /// </summary>
        public int? StepId { get; set; }

        /// <summary>
        /// Gets or sets the order of the steps.
        /// </summary>
        public int StepOrder { get; set; }

        /// <summary>
        /// Gets or sets the validation date of the route by the team.
        /// </summary>
        public DateTime? ValidationDate { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the team route.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the route step linked to the <see cref="StepId"/>
        /// </summary>
        public virtual Routestep RouteStep { get; set; }

        /// <summary>
        /// Gets or sets the game linked to the <see cref="GameId"/>
        /// </summary>
        public virtual Game Game { get; set; }

        /// <summary>
        /// Gets or sets the team linked to the <see cref="TeamId"/>
        /// </summary>
        public virtual Team Team { get; set; }
    }
}
