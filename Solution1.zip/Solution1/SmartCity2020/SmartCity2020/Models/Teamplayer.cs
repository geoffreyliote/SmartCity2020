﻿// <copyright file="Teamplayer.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to a link between team and player.
    /// </summary>
    public partial class Teamplayer
    {
        /// <summary>
        /// Gets or sets the identifier of the <see cref="Team"/>.
        /// </summary>
        public int TeamId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Player"/>
        /// </summary>
        public int PlayerId { get; set; }

        /// <summary>
        /// Gets or sets the player linked to the <see cref="PlayerId"/>
        /// </summary>
        public virtual Player Player { get; set; }

        /// <summary>
        /// Gets or sets the team linked to the <see cref="TeamId"/>
        /// </summary>
        public virtual Team Team { get; set; }
    }
}
