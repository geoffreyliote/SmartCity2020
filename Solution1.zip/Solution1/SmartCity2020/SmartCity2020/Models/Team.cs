﻿// <copyright file="Team.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to a team.
    /// </summary>
    public partial class Team
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Team"/> class.
        /// </summary>
        public Team()
        {
            this.Plays = new List<Play>();
            this.Teamanswers = new List<Teamanswer>();
            this.Teamplayers = new List<Teamplayer>();
            this.Teamroutes = new List<Teamroute>();
        }

        /// <summary>
        /// Gets or sets the identifier of the team.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the team.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Captain"/>.
        /// </summary>
        public int? CaptainId { get; set; }

        /// <summary>
        /// Gets or sets the identifier of the <see cref="Organizer"/>.
        /// </summary>
        public int? OrganizerId { get; set; }

        /// <summary>
        /// Gets or sets the player corresponding to the <see cref="CaptainId"/>.
        /// </summary>
        public virtual Player Captain { get; set; }

        /// <summary>
        /// Gets or sets the organizer corresponding to the <see cref="OrganizerId"/>.
        /// </summary>
        public virtual Organizer Organizer { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Play"/>
        /// </summary>
        public virtual ICollection<Play> Plays { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Teamanswer"/>
        /// </summary>
        public virtual ICollection<Teamanswer> Teamanswers { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Teamplayer"/>
        /// </summary>
        public virtual ICollection<Teamplayer> Teamplayers { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Teamroute"/>
        /// </summary>
        public virtual ICollection<Teamroute> Teamroutes { get; set; }
    }
}
