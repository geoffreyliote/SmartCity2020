﻿// <copyright file="Mission.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Models
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Class corresponding to a mission.
    /// </summary>
    public partial class Mission
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Mission"/> class.
        /// </summary>
        public Mission()
        {
            this.Trials = new List<Trial>();
        }

        /// <summary>
        /// Gets or sets the identifier of the mission.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the identifier to the <see cref="Step"/>.
        /// </summary>
        public int? StepId { get; set; }

        /// <summary>
        /// Gets or sets the description of the mission.
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the score of the mission.
        /// </summary>
        public int? Score { get; set; }

        /// <summary>
        /// Gets or sets the duration of the mission.
        /// </summary>
        public TimeSpan? Time { get; set; }

        /// <summary>
        /// Gets or sets the name of the mission.
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets the step linked to the step identifier seen before.
        /// </summary>
        public virtual Step Step { get; set; }

        /// <summary>
        /// Gets or sets the list of <see cref="Trial"/>.
        /// </summary>
        public virtual ICollection<Trial> Trials { get; set; }
    }
}
