﻿// <copyright file="CookieViewModel.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.ViewModels</summary>
// <author>Team 1</author>
namespace SmartCity2020.ViewModels
{
    using System;
    using System.Windows.Input;
    using Prism.Mvvm;
    using Prism.Navigation;
    using Xamarin.Forms;

    /// <summary>
    /// This is the view model corresponding to the first page of the app.
    /// It will be that which will decide if the app will work or not.
    /// </summary>
    public class CookieViewModel : BindableBase, INavigatedAware
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CookieViewModel"/> class.
        /// </summary>
        /// <param name="navigationService">Navigation service.</param>
        public CookieViewModel(INavigationService navigationService)
        {
            this.NavigationService = navigationService;
            this.Agree = new Command(this.GoToConnect);
            this.Decline = new Command(this.Exit);
        }

        /// <summary>
        /// Gets or sets the navigation service used in this view model.
        /// </summary>
        /// <value>The service which allows navigation.</value>
        public INavigationService NavigationService { get; set; }

        /// <summary>
        /// Gets or sets the command to execute when user click on the agree button.
        /// </summary>
        /// <value>The redirection to the connection page.</value>
        public ICommand Agree { get; set; }

        /// <summary>
        /// Gets or sets the command to execute when user click on the decline button.
        /// </summary>
        /// <value>The exit command.</value>
        public ICommand Decline { get; set; }

        /// <summary>
        /// Method which will redirect on the connection page.
        /// </summary>
        public void GoToConnect()
        {
            this.NavigationService.NavigateAsync("MainPage");
        }

        /// <summary>
        /// Method which will leave the application.
        /// </summary>
        public void Exit()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Method executed when we navigate from this page to another.
        /// </summary>
        /// <param name="parameters">Navigation parameter.</param>
        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        /// <summary>
        /// Method executed when we navigate to this page from another.
        /// </summary>
        /// <param name="parameters">Navigation parameter.</param>
        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}
