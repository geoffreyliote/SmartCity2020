﻿// <copyright file="QuizzPageViewModel.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.ViewModels</summary>
// <author>Team 1</author>
namespace SmartCity2020.ViewModels
{
    using System;
    using System.Collections.Generic;
    using Prism.Commands;
    using Prism.Mvvm;
    using Prism.Navigation;
    using SmartCity2020.Models;
    using SmartCity2020.Services;

    /// <summary>
    /// ViewModel corresponding to the quiz view.
    /// </summary>
    public class QuizzPageViewModel : BindableBase, INavigatedAware
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="QuizzPageViewModel"/> class.
        /// </summary>
        /// <param name="navigationService">Navigation service.</param>
        /// <param name="quizzService">Quiz service.</param>
        public QuizzPageViewModel(INavigationService navigationService, IQuizzService quizzService)
        {
            this.QuizzService = quizzService;
            this.NavigationService = navigationService;
            this.Trials = new List<Trial>();
            this.GoToNextTrial = new DelegateCommand<Answer>(this.NextTrial);

            this.Trials = this.QuizzService.GetTrials(App.CurrentStepId);

            if (App.CurrentQuestionId < this.Trials.Count)
            {
                this.CurrentTrial = this.Trials[App.CurrentQuestionId];
            }
            else
            {
                this.QuizzService.ValidateStep(App.CurrentTeamId);
                this.NavigationService.NavigateAsync("StepPage");
                App.CurrentQuestionId = 0;
            }
        }

        /// <summary>
        /// Gets or sets the service that we use to communicate with the API.
        /// </summary>
        /// <value>Quiz service used in this view model.</value>
        public IQuizzService QuizzService { get; set; }

        /// <summary>
        /// Gets or sets a list of <see cref="Trial"/>.
        /// </summary>
        /// <value>Trials corresponding to the step.</value>
        public List<Trial> Trials { get; set; }

        /// <summary>
        /// Gets or sets the current trial.
        /// </summary>
        /// <value>Current trial of the quiz.</value>
        public Trial CurrentTrial { get; set; }

        /// <summary>
        /// Gets or sets the navigation service.
        /// </summary>
        /// <value>The navigation service used in this view model.</value>
        public INavigationService NavigationService { get; set; }

        /// <summary>
        /// Gets or sets the delegate command that will allow to navigate and get selected answer.
        /// </summary>
        /// <value>Command to go to the next trial of the quiz.</value>
        public DelegateCommand<Answer> GoToNextTrial { get; set; }

        /// <summary>
        /// Gets or sets the id of the answer of the team.
        /// </summary>
        /// <value>Id of the team answer.</value>
        public int AnswerId { get; set; }

        /// <summary>
        /// Go to the next trial corresponding to the step.
        /// </summary>
        /// <param name="answer">The answer of the team.</param>
        public void NextTrial(Answer answer)
        {
            try
            {
                var selectedItem = answer as Answer;
                this.AnswerId = selectedItem.Id;

                this.QuizzService.CheckAnswer(this.AnswerId, App.CurrentTeamId, this.CurrentTrial.Id);

                App.CurrentQuestionId++;
                this.NavigationService.NavigateAsync("QuizzPage");
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Executed when we navigate from this page to another.
        /// </summary>
        /// <param name="parameters">Navigation parameter.</param>
        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        /// <summary>
        /// Executed when we navigate from another page to this one.
        /// </summary>
        /// <param name="parameters">Navigation parameter.</param>
        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}
