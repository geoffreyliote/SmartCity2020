﻿// <copyright file="ValidationPageViewModel.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.ViewModels</summary>
// <author>Team 1</author>
namespace SmartCity2020.ViewModels
{
    using Plugin.Media.Abstractions;
    using Prism.Commands;
    using Prism.Navigation;
    using SmartCity2020.Services;
    using Xamarin.Forms;

    /// <summary>
    /// This is the ViewModel corresponding to the view validation.
    /// We will have information that we need to use in the validation page.
    /// </summary>
    class ValidationPageViewModel
    {
        /// <summary>
        /// The validation service that we use in this view model.
        /// </summary>
        private readonly IValidationService ValidationService;

        /// <summary>
        /// The navigation service that we use in this view model.
        /// </summary>
        private readonly INavigationService NavigationService;
          
        public ValidationPageViewModel(INavigationService navigationService, IValidationService validationService)
        {
            this.NavigationService = navigationService;
            this.ValidationService = validationService;           
            this.ValidationCommand = new DelegateCommand(this.Validate);            
        }

        public MediaFile Photo { get; set; }

        public string IsValide { get; set; }

        public DelegateCommand ValidationCommand { get; private set; }

        public void SetPhoto(MediaFile photo)
        {
            this.Photo = photo;
        }

        private async void Validate()
        {
            if (Photo == null)
            {
                Application.Current.MainPage.DisplayAlert("Error", "You must take a picture first", "Ok");
            }
            else
            {
                var uploadedImageName = await ValidationService.UploadImage(Photo.Path);
                IsValide = await ValidationService.CheckPhoto(App.CurrentTeamId, App.CurrentStepId, uploadedImageName);
                if (IsValide == "")
                {
                    Application.Current.MainPage.DisplayAlert("Success", "Your picture is valid", "Start the quizz !");
                    this.NavigationService.NavigateAsync("QuizzPage");
                }
                else
                {
                    Application.Current.MainPage.DisplayAlert("Erreur", IsValide, "Ok");
                }
            }
            
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}

