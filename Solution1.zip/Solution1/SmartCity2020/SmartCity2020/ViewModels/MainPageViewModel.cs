﻿//-----------------------------------------------------------------------
// <copyright file="MainPageViewModel.cs" company="Diiage">
//     DIIAGE
// </copyright>
// <summary>Located in Smartcity2020.ViewModels</summary>
// <author>Team 1</author>
//-----------------------------------------------------------------------
namespace SmartCity2020.ViewModels
{
    using System.Collections.Generic;
    using System.Windows.Input;
    using JWT;
    using JWT.Algorithms;
    using JWT.Serializers;
    using Prism.Mvvm;
    using Prism.Navigation;
    using SmartCity2020.Services;
    using Xamarin.Forms;

    /// <summary>
    /// View model that refer to the MainPage view.
    /// </summary>
    public class MainPageViewModel : BindableBase, INavigatedAware
    {
        /// <summary>
        /// Navigation Property.
        /// </summary>
        /// <value>The navigation service used in this view model.</value>
        private readonly INavigationService navigationService;

        /// <summary>
        /// Initializes a new instance of the <see cref="MainPageViewModel" /> class.
        /// </summary>
        /// <param name="navigationService">Navigation Service.</param>
        /// <param name="playerService">Allow to use the Player service.</param>
        public MainPageViewModel(INavigationService navigationService, IPlayerService playerService)
        {
            this.navigationService = navigationService;
            this.PlayerService = playerService;
            this.SubmitCommand = new Command(this.OnSubmit);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MainPageViewModel"/> class.
        /// </summary>
        /// <param name="username">Name of the user.</param>
        /// <param name="password">Password of the user.</param>
        public MainPageViewModel(string username, string password)
        {
            this.Username = username;
            this.Password = password;
        }

        /// <summary>
        /// Gets or sets the command.
        /// </summary>
        /// <value>Command which go to profile page of the player.</value>
        public ICommand SubmitCommand { get; protected set; }

        /// <summary>
        /// Gets or sets the name of the user who is trying to connect.
        /// </summary>
        /// <value>Username of the player.</value>
        public string Username { get; set; }

        /// <summary>
        /// Gets or sets the password of the user who is trying to connect.
        /// </summary>
        /// <value>Password of the player.</value>
        public string Password { get; set; }

        /// <summary>
        /// Gets or sets the player's Service.
        /// </summary>
        /// <value>The player service.</value>
        protected IPlayerService PlayerService { get; set; }

        /// <summary>
        /// Method that is executed when the button in the IHM is clicked; execute the login process.
        /// </summary>
        public void OnSubmit()
        {
            var payload = new Dictionary<string, object>()
            {
                { "Username", this.Username }, 
                { "Password", this.Password }
            };

            string secret = "GQDstcKsx0NHjPOuXOYg5MbeJ1XT0uFiwDVvVBrk";
            IJwtAlgorithm algorithm = new HMACSHA256Algorithm();
            IJsonSerializer serializer = new JsonNetSerializer();
            IBase64UrlEncoder urlEncoder = new JwtBase64UrlEncoder();
            IJwtEncoder encoder = new JwtEncoder(algorithm, serializer, urlEncoder);
            var token = encoder.Encode(payload, secret);
            int result;
            if ((result = this.PlayerService.Login(token)) != 0)
            {
                App.IdConnectedPlayer = result;
                this.navigationService.NavigateAsync("ProfilePage");
            }
            else
            {
                Application.Current.MainPage.DisplayAlert("Error", "Incorrect Password or Username", "Ok");
            }
        }

        /// <summary>
        /// Called when the implementer has been navigated away from.
        /// </summary>
        /// <param name="parameters">The navigation parameters.</param>
        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        /// <summary>
        /// Called when the implementer has been navigated to.
        /// </summary>
        /// <param name="parameters">The navigation parameters.</param>
        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}
