﻿// <copyright file="ProfilePageViewModel.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.ViewModels</summary>
// <author>Team 1</author>
namespace SmartCity2020.ViewModels
{
    using System.Windows.Input;
    using Prism.Mvvm;
    using Prism.Navigation;
    using SmartCity2020.Models;
    using SmartCity2020.Services;
    using Xamarin.Forms;

    /// <summary>
    /// This is the ViewModel corresponding to the view ProfilePage.
    /// We will have information that we need to use in the profile page of the user's app.
    /// </summary>
    public class ProfilePageViewModel : BindableBase, INavigatedAware
    {
        /// <summary>
        /// Initializes a new instance of the ProfilePageViewModel class.
        /// </summary>
        /// <param name="navigationService">Allow navigation between pages.</param>
        /// <param name="playerService">Player service.</param>
        /// <param name="teamService">Team service.</param>
        public ProfilePageViewModel(INavigationService navigationService, IPlayerService playerService, ITeamService teamService)
        {
            this.NavigationService = navigationService;
            this.PlayerService = playerService;
            this.TeamService = teamService;
            this.Playerinfo = this.PlayerService.GetInfo(App.IdConnectedPlayer);
            this.CurrentGame = new Command(this.OnCurrentPushed);
            this.Information = new Command(this.OnInformationPushed);
            App.CurrentTeamId = this.TeamService.GetTeam(App.IdConnectedPlayer).Id;
        }

        /// <summary>
        /// Gets or sets the player's info.
        /// </summary>
        /// <value>Information about the player.</value>
        public Playerinfo Playerinfo { get; set; }

        /// <summary>
        /// Gets or sets the command of the current Game.
        /// </summary>
        /// <value>Command to go to the current game of the player.</value>
        public ICommand CurrentGame { get; protected set; }

        /// <summary>
        /// Gets or sets the command of information.
        /// </summary>
        /// <value>Command to go to information about GRPD.</value>
        public ICommand Information { get; set; }

        /// <summary>
        /// Gets or sets the navigation service.
        /// </summary>
        /// <value>The navigation service of the view model.</value>
        public INavigationService NavigationService { get; set; }

        /// <summary>
        /// Gets or sets the player service.
        /// </summary>
        /// <value>The player service used in this view model.</value>
        public IPlayerService PlayerService { get; set; }

        /// <summary>
        /// Gets or sets the team service.
        /// </summary>
        /// <value>The team service used in this view model.</value>
        public ITeamService TeamService { get; set; }

        /// <summary>
        /// Gets or sets the Id of the current player.
        /// </summary>
        /// <value>The player identifier.</value>
        public int IdPlayer { get; set; }

        /// <summary>
        /// Command allowing navigation to the information page.
        /// </summary>
        public void OnInformationPushed()
        {
            this.NavigationService.NavigateAsync("InformationPage");
        }

        /// <summary>
        /// Command allowing navigation to the step page.
        /// </summary>
        public void OnCurrentPushed()
        {
            this.NavigationService.NavigateAsync("StepPage");
        }

        /// <summary>
        /// Called when the implementer has been navigated away from.
        /// </summary>
        /// <param name="parameters">The navigation parameters.</param>
        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        /// <summary>
        /// Called when the implementer has been navigated away to.
        /// </summary>
        /// <param name="parameters">The navigation parameters.</param>
        /// <remarks>Not called when using device hardware or software back buttons.</remarks>
        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}
