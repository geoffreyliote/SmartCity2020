﻿// <copyright file="InformationPageViewModel.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.ViewModels</summary>
// <author>Team 1</author>
namespace SmartCity2020.ViewModels
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    /// <summary>
    /// This is the view model corresponding to the information page of the app.
    /// </summary>
    public class InformationPageViewModel
    {
    }
}
