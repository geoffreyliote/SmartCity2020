﻿// <copyright file="StepPageViewModel.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.ViewModels</summary>
// <author>Team 1</author>
namespace SmartCity2020.ViewModels
{
    using System.Windows.Input;
    using Prism.Mvvm;
    using Prism.Navigation;
    using SmartCity2020.Models;
    using SmartCity2020.Services;
    using Xamarin.Essentials;
    using Xamarin.Forms;

    /// <summary>
    /// This is the view model of the step page.
    /// </summary>
    public class StepPageViewModel : BindableBase, INavigatedAware
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StepPageViewModel"/> class.
        /// </summary>
        /// <param name="navigationService">Navigation service.</param>
        /// <param name="stepService">Step service.</param>
        /// <param name="validationService">Validation service.</param>
        public StepPageViewModel(INavigationService navigationService, StepService stepService, IValidationService validationService)
        {
            this.NavigationService = navigationService;
            this.CurrentTeam = new Command(this.OnCurrentTeamPushed);
            this.ValidateStep = new Command(this.OnValidatePushed);
            this.Stats = new Command(this.OnStatPushed);
            this.ValidationService = validationService;

            this.Step = stepService.GetCurrentStep(1);
            if (this.Step != null)
            {
                App.CurrentStepId = this.Step.Id;
            }
            else
            {
                this.NavigationService.NavigateAsync("ProfilePage");
            }
        }

        /// <summary>
        /// Gets or sets the Validation service.
        /// </summary>
        /// <value>The validation service that we use in this view model.</value>
        public IValidationService ValidationService { get; set; }

        /// <summary>
        /// Gets or sets the navigation service.
        /// </summary>
        /// <value>The navigation service that we use in this view model.</value>
        public INavigationService NavigationService { get; set; }

        /// <summary>
        /// Gets or sets the page where you will go.
        /// </summary>
        /// <value>Command that goes to step validation page.</value>
        public ICommand ValidateStep { get; protected set; }

        /// <summary>
        /// Gets or sets a command to the current team page.
        /// </summary>
        /// <value>Command that goes to current team page.</value>
        public ICommand CurrentTeam { get; protected set; }

        /// <summary>
        /// Gets or sets a command to the stat page.
        /// </summary>
        /// <value>Command that goes to stats page.</value>
        public ICommand Stats { get; set; }

        /// <summary>
        /// Gets or sets a step.
        /// </summary>
        /// <value>The step that we use.</value>
        public Step Step { get; set; }

        /// <summary>
        /// Action to do when we want to navigate to the validation page.
        /// </summary>
        public async void OnValidatePushed()
        {
            if (await this.ValidationService.CheckGeoloc())
            {
                this.NavigationService.NavigateAsync("ValidationPage");
            }
        }

        /// <summary>
        /// Action to do when we want to navigate to the current team page.
        /// </summary>
        public void OnCurrentTeamPushed()
        {
            this.NavigationService.NavigateAsync("TeamMembers");
        }

        /// <summary>
        /// A function that make navigation to the stat page.
        /// </summary>
        public void OnStatPushed()
        {
            this.NavigationService.NavigateAsync("StatPage");
        }

        /// <summary>
        /// Function executed when we navigate from this page to another one.
        /// </summary>
        /// <param name="parameters">Navigation parameter.</param>
        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        /// <summary>
        /// Function executed when we navigate from this page to another.
        /// </summary>
        /// <param name="parameters">Navigation parameter.</param>
        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}
