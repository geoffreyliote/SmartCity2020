﻿// <copyright file="StatPageViewModel.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.ViewModels</summary>
// <author>Team 1</author>
namespace SmartCity2020.ViewModels
{
    using System.Collections.Generic;
    using Prism.Mvvm;
    using Prism.Navigation;
    using SmartCity2020.Entities;
    using SmartCity2020.Models;
    using SmartCity2020.Services;

    /// <summary>
    /// View model for the stat page.
    /// </summary>
    public class StatPageViewModel : BindableBase, INavigatedAware
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StatPageViewModel"/> class.
        /// </summary>
        /// <param name="navigationService">Navigation service.</param>
        /// <param name="statService">Stat service.</param>
        public StatPageViewModel(INavigationService navigationService, IStatService statService)
        {
            this.StatService = statService;
            this.Plays = new List<Play>();
            this.Plays = this.StatService.GetTeamsScores(App.IdConnectedPlayer);
            this.Stats = this.StatService.GetStats(App.CurrentTeamId);
        }

        /// <summary>
        /// Gets or sets the stat service.
        /// </summary>
        /// <value>Stat service that we use in this view model.</value>
        public IStatService StatService { get; set; }

        /// <summary>
        /// Gets or sets stats of the player's current team.
        /// </summary>
        /// <value>Stats that we want to show.</value>
        public TeamInfo Stats { get; set; }

        /// <summary>
        /// Gets or sets a list of <see cref="Play"/>.
        /// </summary>
        /// <value>Plays containing necessaries information.</value>
        public List<Play> Plays { get; set; }

        /// <summary>
        /// Function used when we navigate to a page from this one.
        /// </summary>
        /// <param name="parameters">Navigation parameters.</param>
        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        /// <summary>
        /// Function used when we navigate to this page from another.
        /// </summary>
        /// <param name="parameters">Navigation parameters.</param>
        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}
