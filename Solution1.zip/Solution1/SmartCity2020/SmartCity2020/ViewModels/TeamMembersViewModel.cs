﻿// <copyright file="TeamMembersViewModel.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <summary>Located in Smartcity2020.ViewModels</summary>
// <author>Team 1</author>
namespace SmartCity2020.ViewModels
{
    using System.Collections.Generic;
    using Prism.Mvvm;
    using Prism.Navigation;
    using SmartCity2020.Models;
    using SmartCity2020.Services;

    /// <summary>
    /// This is the ViewModel corresponding to the view TeamMembers.
    /// We will have information that we need to use in the team members page.
    /// </summary>
    public class TeamMembersViewModel : BindableBase, INavigatedAware
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TeamMembersViewModel"/> class.
        /// </summary>
        /// <param name="navigationService">Navigation service.</param>
        /// <param name="teamService">Team service.</param>
        public TeamMembersViewModel(INavigationService navigationService, ITeamService teamService)
        {
            this.TeamService = teamService;
            this.Captain = this.TeamService.GetCaptain(1);
            this.Players = this.TeamService.GetTeamMembers(App.CurrentTeamId);
        }

        /// <summary>
        /// Gets or sets a team service.
        /// </summary>
        /// <value>The team service that we use in this view model.</value>
        public ITeamService TeamService { get; set; }

        /// <summary>
        /// Gets or sets a list of <see cref="Player"/>
        /// </summary>
        /// <value>The list of players of the team.</value>
        public List<Player> Players { get; set; }

        /// <summary>
        /// Gets or sets the <see cref="Player"/> who is the captain of the current team.
        /// </summary>
        /// <value>Captain of the team.</value>
        public Player Captain { get; set; }

        /// <summary>
        /// Function executed when we navigate from this page to another one.
        /// </summary>
        /// <param name="parameters">Navigation parameter.</param>
        public void OnNavigatedFrom(INavigationParameters parameters)
        {
        }

        /// <summary>
        /// Function executed when we navigate from this page to another.
        /// </summary>
        /// <param name="parameters">Navigation parameter.</param>
        public void OnNavigatedTo(INavigationParameters parameters)
        {
        }
    }
}
