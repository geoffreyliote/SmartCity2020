﻿namespace SmartCity2020.Views
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Xamarin.Forms;

    /// <summary>
    /// Auto Generated 
    /// </summary>
    public partial class MainPage : ContentPage
    {
        /// <summary>
        /// Method that render the view
        /// </summary>
        public MainPage()
        {
            InitializeComponent();
        }
    }
}