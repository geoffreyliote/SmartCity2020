﻿using Xamarin.Forms;

namespace SmartCity2020.Views
{
    public partial class Cookie : ContentPage
    {
        public Cookie()
        {
            InitializeComponent();
        }
    }
}
