﻿// <copyright file="ProfilePage.xaml.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Benjamin Sorriaux</author>
namespace SmartCity2020.Views
{
    using Xamarin.Forms;
    using Xamarin.Forms.Xaml;

    /// <summary>
    /// Contains interactions with the corresponding view.
    /// It must be not used here because we are working with Prism.
    /// </summary>
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ProfilePage : ContentPage
    {
        /// <summary>
        /// Initializes a new instance of the ProfilePage class.
        /// </summary>
        public ProfilePage()
        {
            this.InitializeComponent();
        }
    }
}