﻿// <copyright file="App.xaml.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>

using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]

namespace SmartCity2020
{
    using DLToolkit.Forms.Controls;
    using Prism;
    using Prism.Ioc;
    using SmartCity2020.Services;
    using SmartCity2020.ViewModels;
    using SmartCity2020.Views;
    using Xamarin.Forms;

    /// <summary>
    /// Make the navigation of the app.
    /// When a new view is created, you have to add it into RegisterTypes.
    /// OnInitialized is where you select the view that we see when we launch the app.
    /// </summary>
    public partial class App
    {
        /// <summary>
        /// Initializes a new instance of the App class.
        /// </summary>
        public App() : this(null)
        {
        }
        public static int IdConnectedPlayer;
        public static string ApiBaseUrl;
        /// <summary>
        /// Initializes a new instance of the App class.
        /// </summary>
        /// <param name="initializer">Allow to register types.</param>
        public App(IPlatformInitializer initializer) : base(initializer)
        {
        }

        /// <summary>
        /// Gets or sets the id of the current question.
        /// </summary>
        public static int CurrentQuestionId { get; set; }

        /// <summary>
        /// Gets or sets the id of the current step.
        /// </summary>
        public static int CurrentStepId { get; set; }

        /// <summary>
        /// Gets or sets the id of the current team.
        /// </summary>
        public static int CurrentTeamId { get; set; }

        /// <summary>
        /// Here we initialize the app on the selected view.
        /// </summary>
        protected override async void OnInitialized()
        {
            InitializeComponent();
            FlowListView.Init();
            await NavigationService.NavigateAsync("NavigationPage/Cookie");
            CurrentQuestionId = 0;
            CurrentStepId = 0;
            CurrentTeamId = 0;
            IdConnectedPlayer = 1;
            ApiBaseUrl = "http://dijoncityapi.hopto.org/";
        }

        /// <summary>
        /// Here we will add navigation for each view of the app.
        /// We link each view to it's ViewModel.
        /// </summary>
        /// <param name="containerRegistry">A register available on all pages.</param>
        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<NavigationPage>();
            containerRegistry.RegisterForNavigation<MainPage, MainPageViewModel>();
            containerRegistry.RegisterForNavigation<ValidationPage, ValidationPageViewModel>();
            containerRegistry.RegisterForNavigation<ProfilePage, ProfilePageViewModel>();
            containerRegistry.RegisterForNavigation<QuizzPage, QuizzPageViewModel>();
            containerRegistry.RegisterForNavigation<StepPage, StepPageViewModel>();
            containerRegistry.RegisterForNavigation<TeamMembers, TeamMembersViewModel>();
            containerRegistry.RegisterForNavigation<StatPage, StatPageViewModel>();
            containerRegistry.RegisterForNavigation<InformationPage, InformationPageViewModel>();
            containerRegistry.RegisterForNavigation<Cookie, CookieViewModel>();

            containerRegistry.RegisterSingleton<IPlayerService, PlayerService>();
            containerRegistry.RegisterSingleton<ITeamService, TeamService>();
            containerRegistry.RegisterSingleton<IStatService, StatService>();
            containerRegistry.RegisterSingleton<IValidationService, ValidationService>();
            containerRegistry.RegisterSingleton<IPlayerService, PlayerService>();
            containerRegistry.RegisterSingleton<IQuizzService, QuizzService>();
            containerRegistry.RegisterSingleton<IStepService, StepService>();
        }
    }
}
