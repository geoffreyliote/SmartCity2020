using Microsoft.VisualStudio.TestTools.UnitTesting;
using SmartCity2020.Business.Contract;
using SmartCity2020.Entities;
using System.Collections.Generic;
using System.Linq;
using SmartCity2020.WebAPI;

namespace SmartCity2020.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
     
    }
}
