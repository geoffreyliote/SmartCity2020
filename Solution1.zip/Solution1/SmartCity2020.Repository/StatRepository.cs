﻿// <copyright file="StatRepository.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Repository
{
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.EntityFrameworkCore;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;

    /// <summary>
    /// Repository which gets stats from database contexts.
    /// </summary>
    public class StatRepository : IStatRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StatRepository"/> class.
        /// </summary>
        /// <param name="context">Database context.</param>
        public StatRepository(SmartCity2020Context context)
        {
            this.Context = context;
        }

        /// <summary>
        /// Gets or sets the database context.
        /// </summary>
        public SmartCity2020Context Context { get; set; }

        /// <summary>
        /// Gets the number of steps done by the team.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>The number of steps done.</returns>
        public int GetStepsDone(int id) => this.Context.Teamroutes
            .Where(tr => tr.TeamId == id)
            .All(tr => tr.ValidationDate == null)
            ? 0
            : this.Context.Teamroutes
                .Where(tr => tr.TeamId == id)
                .Where(tr => tr.ValidationDate != null)
                .Count();

        /// <summary>
        /// Gets the total number of steps of a game.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>The total number of steps.</returns>
        public int GetTotalSteps(int id) => this.Context.Teamroutes
            .Where(tr => tr.TeamId == id)
            .Count();

        /// <summary>
        /// Gets points of the team.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>Score of the team.</returns>
        //public int GetPoints(int id)
        //{
        //    var team = this.Context.Plays
        //        .FirstOrDefault(p => p.Team.Teamplayers.Any(p => p.PlayerId == id) && p.EndDate != null);
        //    return (team != null)
        //        ? (int)team.Score
        //        : 0;
        //}
        public int GetPoints(int id)
        {
            var team = this.Context.Plays
                .FirstOrDefault(p => p.TeamId == id && p.EndDate == null);
            return (team != null)
                ? (int)team.Score
                : 0;
        }

        /// <summary>
        /// Gets the number of answers of the team.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>The number of answers.</returns>
        public int GetAnswers(int id) => this.Context.Teamanswers
            .Where(ta => ta.TeamId == id)
            .Count();

        /// <summary>
        /// Gets the total number of questions of the game.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>The total number of questions.</returns>
        public int GetTotalQuestions(int id) => this.Context.Trials
            .Where(t => this.Context.Games
                .Any(g => g.Route.Routesteps
                    .Any(rs => rs.StepId == t.Mission.StepId) && g.Plays
                        .Where(p => p.TeamId == id)
                        .Any(pl => pl.StartDate != null && pl.EndDate == null)))
            .Count();

        /// <summary>
        /// Gets the score of all teams participating to the current game of the player.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>A list of plays with teams name.</returns>
        public List<Play> GetTeamsScores(int id) => this.Context.Games
            .Where(g => g.Plays.Any(p => p.Team.Teamplayers.Any(tp => tp.PlayerId == id)))
            .SelectMany(g => g.Plays)
            .Include(p => p.Team)
            .ToList();
    }
}
