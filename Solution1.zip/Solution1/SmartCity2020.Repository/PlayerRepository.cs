﻿//-----------------------------------------------------------------------
// <copyright file="PlayerRepository.cs" company="Diiage">
//     DIIAGE
// </copyright>
// <author>Team 1</author>
//-----------------------------------------------------------------------

namespace SmartCity2020.Repository
{
    using Microsoft.EntityFrameworkCore;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// This is the Repository corresponding to the players.
    /// We will have information that we need to use in the profile page of the user's app.
    /// </summary>
    public class PlayerRepository : IPlayerRepository
    {
        /// <summary>
        /// Initializes a new instance of the PlayerRepository class.
        /// </summary>
        /// <param name="context">Context of the application (database).</param>
        public PlayerRepository(SmartCity2020Context context)
        {
            this.Context = context;
        }

        /// <summary>
        /// Gets or sets the Context of the application
        /// </summary>
        public SmartCity2020Context Context { get; set; }

        /// <summary>
        /// Recover all information of the player into the database
        /// </summary>
        /// <param name="id">Id of the connected player</param>
        /// <returns>Info/Stats of the connected player</returns>
        public Playerinfo GetInfo(int id)
        {
            bool isActualTeamLeader = false;
            if (this.Context.Players
                      .Where(p => p.Id == id)
                      .Select(p => p.Teams
                      .Select(t => t.Plays
                      .Where(pl => pl.StartDate < DateTime.Now && (pl.EndDate == null || pl.EndDate > DateTime.Now)))).FirstOrDefault().Count() == 1)
            {
                isActualTeamLeader = true;
            }

            return new Playerinfo
            {
                Player = this.Context.Players.FirstOrDefault(p => p.Id == id),
                IsActualTeamLeader = isActualTeamLeader,
                NbOfGame = this.Context.Players.Where(pl => pl.Id == id).Select(pl => pl.Teamplayers.Select(tp => tp.Team.Plays)).FirstOrDefault().FirstOrDefault().Count(),
                NbOfSteps = this.Context.Players.Where(p => p.Id == id).Select(p => p.Teamplayers.Select(tp => tp.Team.Teamroutes.Where(tr => tr.ValidationDate != null))).FirstOrDefault().FirstOrDefault().Count(),
                NbOfTeamLeader = this.Context.Teams.Where(t => t.CaptainId == id).Count(),
                NbQrCodeScanned = this.Context.Players.Where(p => p.Id == id).Select(p => p.Teamplayers.Select(tp => tp.Team.Teamanswers.Where(ta => ta.Trial.TypeId == 3))).FirstOrDefault().FirstOrDefault().Count()
        };       
        }
        public int Login(string username, string password)
        {
            var test = this.Context.Players.Where(p => p.Login == username && p.Password == password).FirstOrDefault();
            if (this.Context.Players.Where(p => p.Login == username && p.Password == password).Count() == 1) 
            {
                return this.Context.Players.FirstOrDefault(p => p.Login == username && p.Password == password).Id;
            }
            else
            {
                return 0;
            }
        }
    }
}
