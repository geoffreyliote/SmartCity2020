﻿using SmartCity2020.Entities;
using SmartCity2020.Repository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmartCity2020.Repository
{
    public class RouteRepository : IRouteRepository
    {
        public SmartCity2020Context Context { get; set; }
        public RouteRepository(SmartCity2020Context context)
        {
            Context = context;
        }
        public Route GetRouteForGame(int id)
        {
            return Context.Routes.Where(r => r.Games.Any(g => g.Id == id)).First();
        }

        public IEnumerable<Route> GetRoutes()
        {
            return Context.Routes;
        }

        public IEnumerable<Route> GetRoutesByOrganizer(int organizerId)
        {
            return Context.Routes.Where(r => r.OrganizerId == organizerId);
        }
    }
}
