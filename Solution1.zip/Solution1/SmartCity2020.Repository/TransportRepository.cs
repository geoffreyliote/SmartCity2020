﻿using Microsoft.EntityFrameworkCore;
using SmartCity2020.Entities;
using SmartCity2020.Repository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmartCity2020.Repository
{
    public class TransportRepository  : ITransportRepository
    {
        public SmartCity2020Context Context { get; set; }
        public TransportRepository(SmartCity2020Context context)
        {
            Context = context;
        }
        public IEnumerable<Transport> GetTransports()
        {
            return Context.Transports;
        }
        public List<Trial> PourBenj(int id)
        {
            /// Juste pour aider benj
            throw new NotImplementedException();
            
        }
    }
}
