﻿// <copyright file="QuizzRepository.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Repository
{
    using Microsoft.EntityFrameworkCore;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;
    using System.Collections.Generic;
    using System.Linq;

    public class QuizzRepository :IQuizzRepository
    {
        public QuizzRepository(SmartCity2020Context context)
        {
            Context = context;
        }

        public SmartCity2020Context Context { get; set; }

        public List<Trial> GetTrials(int id) => Context.Trials
            .Where(t => t.Mission.StepId == id)
            .Include(t => t.Answers)
            .ToList();
    }
}
