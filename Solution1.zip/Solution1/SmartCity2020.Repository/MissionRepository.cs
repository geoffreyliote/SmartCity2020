﻿
namespace SmartCity2020.Repository
{
    using Microsoft.EntityFrameworkCore;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using Xamarin.Forms.Internals;

    public class MissionRepository: IMissionRepository
    {
        public MissionRepository(SmartCity2020Context context)
        {
            this.Context = context;
        }

        /// <summary>
        /// Gets or sets the databse context.
        /// </summary>
        public SmartCity2020Context Context { get; set; }

        /// <summary>
        /// Gets the trials of the mission.
        /// </summary>
        /// <param name="id">Mission id.</param>
        /// <returns>A list of <see cref="Trial"/></returns>
        public List<Trial> GetTrials(int id) => this.Context.Trials
            .Where(t => t.MissionId == id)
            .Include(t => t.Answers)
            .ToList();

        /// <summary>
        /// Adds a new item to the list of trials.
        /// </summary>
        /// <param name="newTrial">A trial with its answers.</param>
        public void AddTrial(Trial newTrial, string correctAnswer)
        {
            try
            {
                newTrial.TypeId = 1;
                this.Context.Trials.Add(newTrial);
                this.Context.SaveChanges();

                var trial = this.Context.Trials.Find(newTrial.Id);

                trial.CorrectAnswerId = newTrial.Answers.FirstOrDefault(a => a.Libelle == correctAnswer).Id;
                this.Context.SaveChanges();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Delete a trial from the list of trials.
        /// </summary>
        /// <param name="newTrial">The id of the trial to delete.</param>
        public string DeleteTrial(int id)
        {
            var currentGame = Context.Games
                .Where(g => g.Route.Routesteps
                    .Any(rs => rs.Step.Missions
                        .Any(m => m.Trials
                            .Any(t => t.Id == id))) && g.Plays
                    .Any(p => p.StartDate != null && p.EndDate == null));

            if (currentGame == null)
            {
                var trialToRemove = this.Context.Trials.FirstOrDefault(t => t.Id == id);
                this.Context.Trials.Remove(trialToRemove);
                this.Context.SaveChanges();
                return "Successfully deleted.";
            }
            else
            {
                return "Unable to delete : A game is in progress with this trial.";
            }
        }

        /// <summary>
        /// Edit an existing item from the list of trials.
        /// </summary>
        /// <param name="newTrial">A trial with its answers.</param>
        public void EditTrials(Trial newTrial)
        {
            this.Context.Trials.Update(newTrial);
            this.Context.SaveChanges();
        }

        /// <summary>
        /// Get missions of a step.
        /// </summary>
        /// <param name="newTrial">Id of the step.</param>
        public IEnumerable<Mission> GetStepMission(int idStep)
        {
            return Context.Missions.Where(m => m.StepId == idStep);
        }
    }
}
