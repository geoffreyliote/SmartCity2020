﻿// <copyright file="TeamRepository.cs" company="DIIAGE">
//     DIIAGE.
// </copyright>
// <author>Team 1</author>
namespace SmartCity2020.Repository
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using SmartCity2020.Entities;
    using SmartCity2020.Repository.Contract;
    using Microsoft.EntityFrameworkCore;


    /// <summary>
    /// Repository which gets team information from context.
    /// </summary>
    public class TeamRepository : ITeamRepository
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="TeamRepository"/> class.
        /// </summary>
        /// <param name="context">The context.</param>
        public TeamRepository(SmartCity2020Context context)
        {
            this.Context = context;
        }

        /// <summary>
        /// Gets or sets the context.
        /// </summary>
        public SmartCity2020Context Context { get; set; }

        /// <summary>
        /// Gets the current team of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>The current <see cref="Team"/>.</returns>
        public Team GetTeam(int id)
        {
            return this.Context.Teams
                .Where(t => t.Teamplayers.Any(tp => tp.PlayerId == id))
                .Where(t => t.Plays.Any(p => p.EndDate == null && p.StartDate <= DateTime.Now))
                .FirstOrDefault();
        }
        
        /// <summary>
        /// Gets players of the team.
        /// </summary>
        /// <param name="id">Id of the team.</param>
        /// <returns>A list of <see cref="Player"/></returns>
        public List<Player> GetPlayers(int id)
        {
            return this.Context.Players
                .Where(p => p.Teamplayers.Any(tp => tp.TeamId == id))
                .ToList();
        }

        /// <summary>
        /// Gets the captain of the current team of the player.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>The captain as a <see cref="Player"/>.</returns>
        public Player GetCaptain(int id)
        {
            return this.Context.Players
                .FirstOrDefault(p => p.Id == id);
        }

        /// <summary>
        /// Check if the team answer is corresponding to the correct answer of the trial.
        /// </summary>
        /// <param name="answerId">Id of the concerned answer.</param>
        /// <param name="teamId">Id of the concerned team.</param>
        /// <param name="trialId">Id of the concerned trial.</param>
        public void CheckAnswer(int answerId, int teamId, int trialId)
        {
            try
            {
                var correctAnswer = this.Context.Trials
                    .Where(t => t.Id == trialId)
                    .Select(r => r.CorrectAnswerId)
                    .FirstOrDefault();

                if (correctAnswer == answerId)
                {
                    var team = this.Context.Teams.FirstOrDefault(t => t.Id == teamId);
                    var trial = this.Context.Trials.FirstOrDefault(t => t.Id == trialId);
                    var startDate = this.Context.Plays.FirstOrDefault(p => p.TeamId == teamId && p.EndDate == null).StartDate;
                    team.Plays.FirstOrDefault(p => p.EndDate == null && DateTime.Parse(startDate.ToString()) <= DateTime.Now).Score += trial.Score;
                }

                var game = this.Context.Games.FirstOrDefault(g => g.Plays.Any(p => p.TeamId == teamId && p.EndDate == null));
                this.Context.Teamanswers.Add(new Teamanswer { Id = this.Context.Teamanswers.Any() ? this.Context.Teamanswers.Max(ts => ts.Id) + 1 : 1, AnswerId = answerId, GameId = game.Id, TeamId = teamId, TrialId = trialId });
                this.Context.SaveChanges();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Get the list of team.
        /// </summary>
        /// <param name="id">Id of the player.</param>
        /// <returns>The captain as a <see cref="Player"/>.</returns>
        public List<Team> GetTeams()
        {
                       return Context.Teams.Include(t => t.Captain).Include(t=>t.Organizer).Include(t=>t.Teamplayers).ToList();                
              
        }

       
    }
}
