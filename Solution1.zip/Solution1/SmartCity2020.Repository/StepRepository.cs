﻿using Amazon;
using Amazon.Lambda;
using Amazon.Lambda.Model;
using Amazon.Rekognition;
using Amazon.Rekognition.Model;
using Amazon.S3;
using Amazon.S3.Model;
using SmartCity2020.Entities;
using SmartCity2020.Repository.Contract;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SmartCity2020.Repository
{
    public class StepRepository : IStepRepository
    {

        public SmartCity2020Context Context { get; set; }
        private readonly string accessKey;
        private readonly string secretKey;
        public StepRepository(SmartCity2020Context context)
        {
            Context = context;
            this.accessKey = "AKIASTDT7K7NXMPWR5RW";
            this.secretKey = "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";
        }

        public async Task<string> ValidateStepAsync(int idTeam, int idStep, string uploadedImageName)
        {
            var stringFromDb = this.Context.Steps.FirstOrDefault(s => s.Id == idStep).Validation;
            stringFromDb = stringFromDb.Substring(stringFromDb.LastIndexOf('/') + 1);
            // await UploadToS3( filePath,  fileName);


            var userLabels = await GetStepLabels(uploadedImageName);
            var databaseLabels = await GetStepLabels(stringFromDb);

            var similarities = userLabels.Where(ul => databaseLabels.Contains(ul));
            var similaritiesCount = Convert.ToDouble(similarities.Count());
            var databaseLabelsCount = Convert.ToDouble(databaseLabels.Count());
            var ratio = similaritiesCount / databaseLabelsCount;
            var facereco = UserInPicture(idTeam, uploadedImageName).Result;
            if (ratio >= 0.40 && facereco)
            {
                return "";
            }
            else
            {
                if (ratio >= 0.40 && !facereco)
                {
                    return "Captain not found on the picture";
                }
                if (ratio <= 0.40 && facereco)
                {
                    return "Monument not found on the picture";
                }
                else
                {
                    return "Monument & Captain not found";
                }
            }
        }
        public IEnumerable<Step> GetSteps()
        {
            return Context.Steps;
        }


        private async Task<List<string>> GetStepLabels(string fileName)
        {
            AmazonLambdaClient amazonLambdaClient = new AmazonLambdaClient(accessKey, secretKey, RegionEndpoint.USEast1);
            InvokeRequest ir = new InvokeRequest();
            ir.InvocationType = InvocationType.RequestResponse;
            ir.FunctionName = "Validation";
            ir.Payload = "\"" + fileName + "\"";
            InvokeResponse result = new InvokeResponse();

            result = await amazonLambdaClient.InvokeAsync(ir);


            var strResponse = Encoding.ASCII.GetString(result.Payload.ToArray());
            var stringArray = Regex.Split(strResponse, @"(?<!^)(?=[A-Z])");//
            List<string> labels = new List<string>(stringArray);
            labels.Remove("\"");
            labels[labels.Count - 1] = labels[labels.Count - 1].Remove(labels[labels.Count - 1].Length - 1);

            return labels;
        }

        private async Task<bool> UserInPicture(int teamId, string filename)
        {
            try
            {
                var teamLeaderPic = Context.Teams.Where(t => t.Id == teamId).Select(t => t.Captain.Picture).FirstOrDefault();
                var amazonRek = new AmazonRekognitionClient(accessKey, secretKey, RegionEndpoint.USEast1);
                teamLeaderPic = teamLeaderPic.Substring(teamLeaderPic.LastIndexOf('/') + 1);

                var source = new Image
                {
                    S3Object = new Amazon.Rekognition.Model.S3Object
                    {
                        Bucket = "tagsverification",
                        Name = filename

                    }
                };
                var target = new Image
                {
                    S3Object = new Amazon.Rekognition.Model.S3Object
                    {
                        Bucket = "tagsverification",
                        Name = teamLeaderPic
                    }
                };
                var response = amazonRek.CompareFacesAsync(new CompareFacesRequest
                {
                    SimilarityThreshold = 90,
                    SourceImage = source,
                    TargetImage = target
                });
                List<CompareFacesMatch> faceMatches = response.Result.FaceMatches;
                if (faceMatches.Count >= 1)
                {
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {

                throw e;
            }

        }

        /// <summary>
        /// Get the current step of the team which contain the player passed in id.
        /// </summary>
        /// <param name="id">Player id.</param>
        /// <returns>Current step of the team of the player.</returns>
        public Step GetCurrentStep(int id) => Context.Teamroutes
            .Where(tr => tr.Team.Teamplayers
            .Any(p => p.PlayerId == id))
            .Where(tr => tr.ValidationDate == null)
            .OrderBy(tr => tr.StepOrder)
            .Select(tr => tr.RouteStep.Step)
            .FirstOrDefault();

        /// <summary>
        /// Set a validation date to the step when all questions are answered.
        /// </summary>
        /// <param name="id">Team id.</param>
        public void QuizzValidation(int id)
        {
            var step = Context.Teamroutes
                .Where(tr => tr.TeamId == id && tr.ValidationDate == null)
                .OrderBy(tr => tr.StepOrder)
                .FirstOrDefault();
            step.ValidationDate = DateTime.Now;
            Context.SaveChanges();

        }
        public Step GetStep(int id)
        {
            return Context.Steps.Find(id);
        }
        public void PostStep(Step step)
        {
            step.CreationDate = DateTime.Now;
            Context.Steps.Add(step);
            Context.SaveChanges();
        }
        public void EditStep(Step step)
        {
            step.CreationDate = DateTime.Now;
            Context.Steps.Update(step);
            Context.SaveChanges();
        }
        public async Task UploadToS3(FileStream fileStream)
        {
            var client = new AmazonS3Client(this.accessKey, this.secretKey, RegionEndpoint.USEast1);
            Uri uri = new Uri(fileStream.Name);
            var request = new PutObjectRequest
            {
                BucketName = "tagsverification",
                Key = accessKey,
                FilePath = "C:/Users/Geoffrey/Source/Repos/SmartCity2020/Solution1/SmartCity2020/SmartCity2020/file.jpg"
            };
            PutObjectResponse response = await client.PutObjectAsync(request);
        }
        public string DeleteStep(int id)
        {
            var currentRoute = Context.Routes
                .Where(r => r.Routesteps.Any(rs => rs.StepId == id)).Count();
            if (currentRoute == 0)
            {
                var stepToRemove = this.Context.Steps.FirstOrDefault(s => s.Id == id);
                this.Context.Steps.Remove(stepToRemove);
                this.Context.SaveChanges();
                return "Successfully deleted.";
            }
            else
            {
                return "Unable to delete : A Route contain this Step.";
            }
        }

    }
}
        
        

        
     


