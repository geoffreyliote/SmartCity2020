﻿using Microsoft.EntityFrameworkCore;
using SmartCity2020.Entities;
using SmartCity2020.Repository.Contract;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SmartCity2020.Repository
{
    public class GameRepository : IGameRepository
    {
        public SmartCity2020Context Context { get; set; }
        public GameRepository(SmartCity2020Context context)
        {
            Context = context;
        }
        public IEnumerable<Game> GetGames()
        {
            return Context.Games
                .Where(g =>g.Plays.All(p => p.EndDate != null))
                .Include(g => g.Organizer)
                .Include(g => g.Route)
                .Include(g => g.Transport)
                ;
        }

        public IEnumerable<Game> GetActiveGame(int id)
        {
            return Context.Games
                .Where(g => g.OrganizerId == id)
                .Where(g => g.Plays.Any(p=>p.EndDate == null))
                .Include(g => g.Route)
                .Include(g => g.Transport)
                .Include(g => g.Organizer);
        }
        public IEnumerable<Team> GetTeamplayers(int id)
        {
            return Context.Teams
                .Where(t => Context.Plays
                    .Where(p => p.GameId == id)
                    .Any(p => p.TeamId == t.Id))
                .Include(t => t.Teamplayers)
                .ThenInclude(tp => tp.Player)
                .Select(x => new Team
                {
                    Captain = new Player
                    {
                        FirstName = x.Captain.FirstName,
                        LastName = x.Captain.LastName,
                        Id = x.Captain.Id,

                        
                    },
                    CaptainId = x.CaptainId,
                    Id = x.Id,
                    Name = x.Name,
                    Organizer = new Organizer
                    {
                        Id = x.Organizer.Id,
                        FirstName = x.Organizer.FirstName,
                        LastName = x.Organizer.LastName,
                    },
                    OrganizerId = x.OrganizerId,
                    Plays = x.Plays,
                    Teamanswers = x.Teamanswers,
                    Teamplayers = x.Teamplayers.Select(tp => new Teamplayer
                    {
                        Player = new Player
                        {
                            FirstName = tp.Player.FirstName,
                            LastName = tp.Player.LastName,
                            Id = tp.Player.Id
                        }
                    }).ToList(),
                    Teamroutes = x.Teamroutes,

                }); 
        }

        public object GetGameProgression(int id)
        {
            return Context.Teamroutes
                .Where(tr => tr.GameId == id)
                .OrderBy(tr => tr.StepOrder)
                .Select(r => new
                {
                    r.TeamId,
                    r.StepOrder,
                    r.StepId,
                    Completed = (r.ValidationDate != null) ? true : false,
                    r.RouteStep.Step.Name,
                }) ;
        }
        public List<Step> GetStepsOfGame(int id)
        {
            return Context.Steps.Where(s => Context.Games
                .Where(g => g.Id == id)
                .Any(g => g.Route.Routesteps
                    .Any(rs => rs.StepId == s.Id)))
                .ToList();
        }
    }
}
