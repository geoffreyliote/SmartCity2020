﻿using System;

namespace SmartCity2020.EntitiesContext
{
    public class Class1
    {
    }
}
